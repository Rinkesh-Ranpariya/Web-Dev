import "./App.css";
import { useState } from "react";
import ActorsFilter from "./components/ActorsFilter";
import GenreFilter from "./components/GenreFilter";
import TypeFilter from "./components/TypeFilter";
import Table from "./components/Table";
import { uniqBy } from "lodash";
import { data } from "./data";

function App() {
  // ========================================================================
  const [genreData, setGenreData] = useState([]);
  const [actorsData, setActorsData] = useState([]);
  const [typeData, setTypeData] = useState([]);

  const handleGenre = (genre) => {
    setGenreData(Array.isArray(genre) ? genre.map((ele) => ele.label) : []);
  };

  const handleActors = (e) => {
    setActorsData(Array.isArray(e) ? e.map((ele) => ele.label) : []);
  };

  const handleType = (e) => {
    setTypeData(Array.isArray(e) ? e.map((ele) => ele.label) : []);
  };

  // ==========================================================================
  //Unique value for drop down

  // let duplicatedGenreFullArray = [];
  // let duplicatedActorsFullArray = [];
  // let duplicatedTypeFullArray = [];

  // data.map((row) => {
  //   let GenreArray = String(row.Genre).split(", ");
  //   let ActorsArray = String(row.Actors).split(", ");
  //   let TypeArray = String(row.Type).split(", ");

  //   duplicatedGenreFullArray = [...duplicatedGenreFullArray, ...GenreArray];
  //   duplicatedActorsFullArray = [...duplicatedActorsFullArray, ...ActorsArray];
  //   duplicatedTypeFullArray = [...duplicatedTypeFullArray, ...TypeArray];
  // });

  // let GenreFullArray = uniqBy(duplicatedGenreFullArray).sort();
  // let ActorsFullArray = uniqBy(duplicatedActorsFullArray).sort();
  // let TypeFullArray = uniqBy(duplicatedTypeFullArray).sort();

  let GenreFullArray = [];
  let ActorsFullArray = [];
  let TypeFullArray = [];

  data.map((row) => {
    let GenreArray = String(row.Genre).split(", ");
    let ActorsArray = String(row.Actors).split(", ");
    let TypeArray = String(row.Type).split(", ");

    GenreFullArray = uniqBy([...GenreFullArray, ...GenreArray]);
    ActorsFullArray = uniqBy([...ActorsFullArray, ...ActorsArray]);
    TypeFullArray = uniqBy([...TypeFullArray, ...TypeArray]);
  });

  // =============================================================================
  //filter

  let dataFilter =
    typeData.length > 0
      ? data.filter((eleType) => {
          let TypeArray = String(eleType.Type).split(", ");

          for (const ele of typeData) {
            if (TypeArray.includes(ele)) {
              return true;
            }
          }
        })
      : data;

  dataFilter =
    genreData.length > 0
      ? dataFilter.filter((eleGenre) => {
          let GenreArray = String(eleGenre.Genre).split(", ");

          for (const ele of genreData) {
            if (GenreArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;

  dataFilter =
    actorsData.length > 0
      ? dataFilter.filter((eleActors) => {
          let ActorsArray = String(eleActors.Actors).split(", ");

          for (const ele of actorsData) {
            if (ActorsArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;

  // ====================================================================================

  return (
    <div className="App">
      <div className="select mt-3">
        <GenreFilter
          GenreFullArray={GenreFullArray}
          handleGenre={handleGenre}
        />
        <ActorsFilter
          ActorsFullArray={ActorsFullArray}
          handleActors={handleActors}
        />
        <TypeFilter TypeFullArray={TypeFullArray} handleType={handleType} />
      </div>
      <Table dataFilter={dataFilter} />
    </div>
  );
}

export default App;
