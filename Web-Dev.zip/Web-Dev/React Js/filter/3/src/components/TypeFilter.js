import React from "react";
import Select from "react-select";

function TypeFilter({ TypeFullArray, handleType }) {
  const typeOptions = TypeFullArray.map((ele) => {
    return { label: ele, value: ele };
  });

  return (
    <div>
      <h5>Select Type</h5>
      <Select
        isMulti
        name="type"
        options={typeOptions}
        className="basic-multi-select"
        classNamePrefix="select"
        onChange={handleType}
      />
    </div>
  );
}

export default TypeFilter;
