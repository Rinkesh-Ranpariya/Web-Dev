import React from "react";
import Select from "react-select";

function GenreFilter({ GenreFullArray, handleGenre }) {
  const genreOptions = GenreFullArray.map((ele) => {
    return { label: ele, value: ele };
  });

  return (
    <div>
      <h5>Select Genre</h5>
      <Select
        isMulti
        name="genre"
        options={genreOptions}
        className="basic-multi-select"
        classNamePrefix="select"
        onChange={handleGenre}
      />
    </div>
  );
}

export default GenreFilter;
