import React, { useState } from "react";
import Select from "react-select";

const options = [
  { label: "Grapes 🍇", value: 1 },
  { label: "Mango 🥭", value: 2 },
  { label: "Strawberry 🍓", value: 3, disabled: true },
];

const Selected = () => {
  const [selected, setSelected] = useState(null);

  const handleSelected = (e) => {
    console.log(e);
    setSelected(Array.isArray(e) ? e.map((ele) => ele.label) : []);
  };

  return (
    <>
      <div>
        <h1>Select Fruits</h1>
        <Select
          isMulti
          // name="colors"
          options={options}
          className="basic-multi-select"
          classNamePrefix="select"
          onChange={handleSelected}
        />
      </div>
      <div>{selected}</div>
    </>
  );
};

export default Selected;
