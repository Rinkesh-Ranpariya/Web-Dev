import "./App.css";
import React from "react";
import { useState } from "react";
import ActorsFilter from "./components/ActorsFilter";
import GenreFilter from "./components/GenreFilter";
import TypeFilter from "./components/TypeFilter";
import Table from "./components/Table";
import { uniqBy } from "lodash";
import { data } from "./data";
import Modal from "./components/Modal";
import { Button } from "react-bootstrap";

// ==========================================================================
//Unique value for drop down

let genreFullArray = [];
let actorsFullArray = [];
let typeFullArray = [];

data.forEach((row) => {
  let genreArray = row.Genre.split(", ");
  let actorsArray = row.Actors.split(", ");
  let typeArray = row.Type.split(", ");

  genreFullArray = uniqBy([...genreFullArray, ...genreArray]).sort();
  actorsFullArray = uniqBy([...actorsFullArray, ...actorsArray]).sort();
  typeFullArray = uniqBy([...typeFullArray, ...typeArray]).sort();
});

function App() {
  // ========================================================================
  //state
  const [modalShow, setModalShow] = useState(false);
  const [genreData, setGenreData] = useState([]);
  const [actorsData, setActorsData] = useState([]);
  const [typeData, setTypeData] = useState([]);

  const handleGenre = (genre) => {
    setGenreData(Array.isArray(genre) ? genre.map((ele) => ele.label) : []);
  };

  const handleActors = (actors) => {
    setActorsData(Array.isArray(actors) ? actors.map((ele) => ele.label) : []);
  };

  const handleType = (type) => {
    setTypeData(Array.isArray(type) ? type.map((ele) => ele.label) : []);
  };

  // =============================================================================
  //filter

  let dataFilter =
    typeData.length > 0
      ? data.filter((eleType) => {
          let typeArray = eleType.Type.split(", ");
          for (const ele of typeData) {
            if (typeArray.includes(ele)) {
              return true;
            }
          }
        })
      : data;

  dataFilter =
    genreData.length > 0
      ? dataFilter.filter((eleGenre) => {
          let genreArray = eleGenre.Genre.split(", ");

          for (const ele of genreData) {
            if (genreArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;

  dataFilter =
    actorsData.length > 0
      ? dataFilter.filter((eleActors) => {
          let actorsArray = eleActors.Actors.split(", ");

          for (const ele of actorsData) {
            if (actorsArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;

  // ====================================================================================

  return (
    <div className="App">
      <Button variant="primary" onClick={() => setModalShow(true)}>
        Launch vertically centered modal
      </Button>

      <Modal show={modalShow} onHide={() => setModalShow(false)} />

      <div className="select mt-3">
        <GenreFilter
          genreFullArray={genreFullArray}
          handleGenre={handleGenre}
        />
        <ActorsFilter
          actorsFullArray={actorsFullArray}
          handleActors={handleActors}
        />
        <TypeFilter typeFullArray={typeFullArray} handleType={handleType} />
      </div>
      <Table dataFilter={dataFilter} />
    </div>
  );
}

export default App;
