import React from "react";
import Select from "react-select";

function ActorsFilter({ actorsFullArray, handleActors }) {
  const actorsOptions = actorsFullArray.map((ele) => {
    return { label: ele, value: ele };
  });

  return (
    <div>
      <h5>Select Actors</h5>
      <Select
        isMulti
        name="actors"
        options={actorsOptions}
        className="basic-multi-select"
        classNamePrefix="select"
        onChange={handleActors}
      />
    </div>
  );
}

export default ActorsFilter;
