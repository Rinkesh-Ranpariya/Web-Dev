import "./App.css";
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { uniqBy } from "lodash";
import ActorsFilter from "./components/ActorsFilter";
import GenreFilter from "./components/GenreFilter";
import TypeFilter from "./components/TypeFilter";
import Modal from "./components/Modal";
import Table from "./components/Table";
import { addData } from "./redux/addData/addDataAction";

function App({ data, addData }) {
  //state
  const [modalData, setModalData] = useState({
    Title: "",
    Genre: "",
    Actors: "",
    Type: "",
  });
  const [genreSelectedData, setGenreSelectedData] = useState([]);
  const [actorsSelectedData, setActorsSelectedData] = useState([]);
  const [typeSelectedData, setTypeSelectedData] = useState([]);

  const handleGenre = (genre) => {
    setGenreSelectedData(
      Array.isArray(genre) ? genre.map((ele) => ele.label) : []
    );
  };

  const handleActors = (actors) => {
    setActorsSelectedData(
      Array.isArray(actors) ? actors.map((ele) => ele.label) : []
    );
  };

  const handleType = (type) => {
    setTypeSelectedData(
      Array.isArray(type) ? type.map((ele) => ele.label) : []
    );
  };

  // ==========================================================================
  //Unique value for drop down

  let genreFullArray = [];
  let actorsFullArray = [];
  let typeFullArray = [];
  data.forEach((row) => {
    const genreTempArray = row.Genre.split(", ");
    const actorsTempArray = row.Actors.split(", ");
    const typeTempArray = row.Type.split(", ");

    genreFullArray = uniqBy([...genreFullArray, ...genreTempArray]).sort();
    actorsFullArray = uniqBy([...actorsFullArray, ...actorsTempArray]).sort();
    typeFullArray = uniqBy([...typeFullArray, ...typeTempArray]).sort();
  });

  // =============================================================================
  //filter

  let dataFilter;
  // useEffect(() => {
  dataFilter =
    typeSelectedData.length > 0
      ? data.filter((eleType) => {
          const typeTempArray = eleType.Type.split(", ");
          for (const ele of typeSelectedData) {
            if (typeTempArray.includes(ele)) {
              return true;
            }
          }
        })
      : data;

  dataFilter =
    genreSelectedData.length > 0
      ? dataFilter.filter((eleGenre) => {
          const genreTempArray = eleGenre.Genre.split(", ");
          for (const ele of genreSelectedData) {
            if (genreTempArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;

  dataFilter =
    actorsSelectedData.length > 0
      ? dataFilter.filter((eleActors) => {
          const actorsTempArray = eleActors.Actors.split(", ");
          for (const ele of actorsSelectedData) {
            if (actorsTempArray.includes(ele)) {
              return true;
            }
          }
        })
      : dataFilter;
  // }, [genreSelectedData, actorsSelectedData, typeData]);

  // ====================================================================================
  //add new data

  const handlerInputChange = (e) => {
    setModalData({
      ...modalData,
      [e.target.name]: e.target.value
        .split(",")
        .map((ele) => ele.trim())
        .join(", "),
    });
  };

  const handlerFormSubmit = () => {
    addData(modalData);
    setModalData({
      Title: "",
      Genre: "",
      Actors: "",
      Type: "",
    });
  };

  // =================================================================================

  return (
    <div className="App">
      <input
        type="button"
        value="Add Data"
        className="btn btn-primary d-block mx-auto m-3"
        data-toggle="modal"
        data-target="#exampleModal"
      />
      <div className="select mt-3">
        <GenreFilter
          genreFullArray={genreFullArray}
          handleGenre={handleGenre}
        />
        <ActorsFilter
          actorsFullArray={actorsFullArray}
          handleActors={handleActors}
        />
        <TypeFilter typeFullArray={typeFullArray} handleType={handleType} />
      </div>
      <Table dataFilter={dataFilter} />

      <Modal
        handlerInputChange={handlerInputChange}
        handlerFormSubmit={handlerFormSubmit}
      />
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    data: state.initialData,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    addData: (newRow) => dispatch(addData(newRow)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
