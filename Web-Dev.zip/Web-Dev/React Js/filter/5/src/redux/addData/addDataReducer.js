import { ADD_DATA } from "./addDataType";
import { data } from "../../data";

const initialState = {
  initialData: data,
};

const addDataReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_DATA:
      return {
        initialData: [...state.initialData, action.payload],
      };

    default:
      return state;
  }
};

export default addDataReducer;
