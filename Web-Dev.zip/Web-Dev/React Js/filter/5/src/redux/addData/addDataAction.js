import { ADD_DATA } from "./addDataType";

export const addData = (data) => {
  return {
    type: ADD_DATA,
    payload: data,
  };
};
