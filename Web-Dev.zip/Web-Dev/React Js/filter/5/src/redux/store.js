import { createStore } from "redux";
import addDataReducer from "./addData/addDataReducer";

const store = createStore(addDataReducer);

export default store;
