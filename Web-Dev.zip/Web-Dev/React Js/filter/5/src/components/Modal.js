import React from "react";

function Modal({ handlerInputChange, handlerFormSubmit }) {
  return (
    <>
      <div className="modal fade" id="exampleModal" tabIndex="-1">
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="modal-title">
                Fill Data
              </h5>
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div className="modal-body" id="modal-body">
              <p>
                Title :{" "}
                <input
                  type="text"
                  name="Title"
                  id="title"
                  onChange={handlerInputChange}
                />
              </p>
              <p>
                Genre :{" "}
                <input
                  type="text"
                  name="Genre"
                  id="genre"
                  onChange={handlerInputChange}
                />
              </p>
              <p>
                Actors :{" "}
                <input
                  type="text"
                  name="Actors"
                  id="actors"
                  onChange={handlerInputChange}
                />
              </p>
              <p>
                Type :{" "}
                <input
                  type="text"
                  name="Type"
                  id="type"
                  onChange={handlerInputChange}
                />
              </p>
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                data-dismiss="modal"
                onClick={handlerFormSubmit}
              >
                Add Data
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Modal;
