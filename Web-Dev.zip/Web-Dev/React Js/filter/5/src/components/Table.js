import React from "react";
import { data } from "../data";

function Table({ dataFilter }) {
  return (
    <div className="mt-3">
      <table className="table">
        <thead className="thead-dark">
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Genre</th>
            <th scope="col">Actors</th>
            <th scope="col">Type</th>
          </tr>
        </thead>
        <tbody>
          <>
            {dataFilter.map((row) => {
              return (
                <tr key={row.imdbID}>
                  <th scope="row">{row.Title}</th>
                  <td>{row.Genre}</td>
                  <td>{row.Actors}</td>
                  <td>{row.Type}</td>
                </tr>
              );
            })}
          </>
        </tbody>
      </table>
    </div>
  );
}

export default Table;
