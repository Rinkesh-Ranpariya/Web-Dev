import { useEffect, useState } from "react";
import "./App.css";
import dataFunction from "./data";

function App() {
  console.log("render");
  const data = dataFunction();

  const [dataFilter, setDataFilter] = useState([]);

  // =============================================================
  const [genreData, setGenreData] = useState([]);

  const handleGenre = (name) => {
    let arrGenre = [...genreData];
    if (arrGenre.includes(name)) {
      let index = arrGenre.indexOf(name);
      arrGenre.splice(index, 1);
      setGenreData([...arrGenre]);
    } else {
      setGenreData([...genreData, name]);
    }
  };

  // ================================================================
  const [actorsData, setActorsData] = useState([]);

  const handleActors = (name) => {
    setActorsData([...actorsData, name]);

    let arrayActors = [...actorsData];
    if (arrayActors.includes(name)) {
      let index = arrayActors.indexOf(name);
      arrayActors.splice(index, 1);
      setActorsData([...arrayActors]);
    } else {
      setActorsData([...actorsData, name]);
    }
  };

  // ====================================================================
  const [typeData, setTypeData] = useState([]);

  const handleType = (name) => {
    let arrType = [...typeData];
    if (arrType.includes(name)) {
      let index = arrType.indexOf(name);
      arrType.splice(index, 1);
      setTypeData([...arrType]);
    } else {
      setTypeData([...typeData, name]);
    }
  };

  // console.log(genreData);
  // console.log(actorsData);
  // console.log(typeData);

  // ==========================================================================
  //Unique value for drop down

  let GenreFullArray = [];
  let ActorsFullArray = [];
  let TypeFullArray = [];

  data.map((row) => {
    let GenreArray = String(row.Genre).split(", ");
    let ActorsArray = String(row.Actors).split(", ");
    let TypeArray = String(row.Type).split(", ");

    // for (const GenreArrayElement of GenreArray) {
    //   let Genreflag = false;
    //   for (const GenreFullArrayElement of GenreFullArray) {
    //     if (GenreArrayElement == GenreFullArrayElement) {
    //       Genreflag = true;
    //       break;
    //     }
    //   }
    //   if (Genreflag == false) {
    //     GenreFullArray.push(GenreArrayElement);
    //   }
    // }

    for (const GenreArrayElement of GenreArray) {
      if (GenreFullArray.includes(GenreArrayElement)) {
        continue;
      } else {
        GenreFullArray.push(GenreArrayElement);
      }
    }

    // for (const ActorsArrayElement of ActorsArray) {
    //   let Actorsflag = false;
    //   for (const ActorsFullArrayElement of ActorsFullArray) {
    //     if (ActorsArrayElement == ActorsFullArrayElement) {
    //       Actorsflag = true;
    //       break;
    //     }
    //   }
    //   if (Actorsflag == false) {
    //     ActorsFullArray.push(ActorsArrayElement);
    //   }
    // }

    for (const ActorsArrayElement of ActorsArray) {
      if (ActorsFullArray.includes(ActorsArrayElement)) {
        continue;
      } else {
        ActorsFullArray.push(ActorsArrayElement);
      }
    }

    // for (const TypeArrayElement of TypeArray) {
    //   let Typeflag = false;
    //   for (const TypeFullArrayElement of TypeFullArray) {
    //     if (TypeArrayElement == TypeFullArrayElement) {
    //       Typeflag = true;
    //       break;
    //     }
    //   }
    //   if (Typeflag == false) {
    //     TypeFullArray.push(TypeArrayElement);
    //   }
    // }

    for (const TypeArrayElement of TypeArray) {
      if (TypeFullArray.includes(TypeArrayElement)) {
        continue;
      } else {
        TypeFullArray.push(TypeArrayElement);
      }
    }
  });

  // =========================================================================

  // useEffect(() => {
  //   let GenreArrayFilter = dataFilter.filter((eleGenre) => {
  //     let GenreArray = String(eleGenre.Genre).split(", ");

  //     for (const ele of genreData) {
  //       if (GenreArray.includes(ele)) {
  //         return true;
  //       }
  //     }
  //   });
  //   console.log(GenreArrayFilter);
  //   setTimeout(() => {
  //     setDataFilter([...GenreArrayFilter]);
  //   }, 2000);
  // }, [genreData]);

  // useEffect(() => {
  //   let ActorsArrayFilter = dataFilter.filter((eleActors) => {
  //     let ActorsArray = String(eleActors.Actors).split(", ");

  //     for (const ele of actorsData) {
  //       if (ActorsArray.includes(ele)) {
  //         return true;
  //       }
  //     }
  //   });
  //   console.log(ActorsArrayFilter);
  //   // setDataFilter([...ActorsArrayFilter]);
  // }, [actorsData]);

  // useEffect(() => {
  //   let TypeArrayFilter = dataFilter.filter((eleType) => {
  //     let TypeArray = String(eleType.Type).split(", ");

  //     for (const ele of typeData) {
  //       if (TypeArray.includes(ele)) {
  //         return true;
  //       }
  //     }
  //   });
  //   console.log("====", TypeArrayFilter);
  //   // setDataFilter([...TypeArrayFilter]);
  // }, [typeData]);

  useEffect(() => {
    if (typeData.length > 0) {
      let TypeArrayFilter = data.filter((eleType) => {
        let TypeArray = String(eleType.Type).split(", ");

        for (const ele of typeData) {
          if (TypeArray.includes(ele)) {
            return true;
          }
        }
      });
      setDataFilter([...TypeArrayFilter]);
    }
  }, [typeData]);

  // ====================================================================================

  return (
    <div className="App">
      <div className="select">
        <div className="dropdown">
          <a
            className="btn btn-secondary dropdown-toggle"
            href="#"
            role="button"
            id="dropdownMenuLink"
            data-toggle="dropdown"
            aria-expanded="false"
          >
            Genre
          </a>

          <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
            {GenreFullArray.map((ele, index) => (
              <div className="d-flex align-items-center" key={index}>
                <input
                  type="checkbox"
                  name={ele}
                  id={ele}
                  onChange={(e) => handleGenre(e.target.name)}
                />
                <a className="dropdown-item" href="#">
                  {ele}
                </a>
              </div>
            ))}
          </div>
        </div>

        <div className="dropdown">
          <a
            className="btn btn-secondary dropdown-toggle"
            href="#"
            role="button"
            id="dropdownMenuLink"
            data-toggle="dropdown"
            aria-expanded="false"
          >
            Actors
          </a>

          <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
            {ActorsFullArray.map((ele, index) => (
              <div className="d-flex align-items-center" key={index}>
                <input
                  type="checkbox"
                  name={ele}
                  id={ele}
                  onChange={(e) => handleActors(e.target.name)}
                />
                <a className="dropdown-item" href="#">
                  {ele}
                </a>
              </div>
            ))}
          </div>
        </div>

        <div className="dropdown">
          <a
            className="btn btn-secondary dropdown-toggle"
            href="#"
            role="button"
            id="dropdownMenuLink"
            data-toggle="dropdown"
            aria-expanded="false"
          >
            Type
          </a>

          <div className="dropdown-menu" aria-labelledby="dropdownMenuLink">
            {TypeFullArray.map((ele, index) => (
              <div className="d-flex align-items-center" key={index}>
                <input
                  type="checkbox"
                  name={ele}
                  id={ele}
                  onChange={(e) => handleType(e.target.name)}
                />
                <a className="dropdown-item" href="#">
                  {ele}
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
      <table className="table">
        <thead className="thead-dark">
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Genre</th>
            <th scope="col">Actors</th>
            <th scope="col">Type</th>
          </tr>
        </thead>
        <tbody>
          {typeData.length > 0 ||
          genreData.length > 0 ||
          actorsData.length > 0 ? (
            <>
              {dataFilter.map((row) => {
                return (
                  <tr key={row.imdbID}>
                    <th scope="row">{row.Title}</th>
                    <td>{row.Genre}</td>
                    <td>{row.Actors}</td>
                    <td>{row.Type}</td>
                  </tr>
                );
              })}
            </>
          ) : (
            data.map((row) => {
              return (
                <tr key={row.imdbID}>
                  <th scope="row">{row.Title}</th>
                  <td>{row.Genre}</td>
                  <td>{row.Actors}</td>
                  <td>{row.Type}</td>
                </tr>
              );
            })
          )}

          {/* {typeData.length > 0 || genreData.length > 0 || actorsData.length > 0
            ? data.map((row) => {
                let GenreArray = String(row.Genre).split(", ");
                let ActorsArray = String(row.Actors).split(", ");
                let TypeArray = String(row.Type).split(", ");

                for (const ele of typeData) {
                  if (TypeArray.includes(ele)) {
                    return (
                      <tr key={row.imdbID}>
                        <th scope="row">{row.Title}</th>
                        <td>{row.Genre}</td>
                        <td>{row.Actors}</td>
                        <td>{row.Type}</td>
                      </tr>
                    );
                  }
                }
              })
            : data.map((row) => {
                return (
                  <tr key={row.imdbID}>
                    <th scope="row">{row.Title}</th>
                    <td>{row.Genre}</td>
                    <td>{row.Actors}</td>
                    <td>{row.Type}</td>
                  </tr>
                );
              })} */}
        </tbody>
      </table>
    </div>
  );
}

export default App;
