import React from "react";
import ChildA from "./ChildA";

export const nameContext = React.createContext();
export const surnameContext = React.createContext();

function Context() {
  return (
    <>
      <h1>useContext Hook🪝</h1>
      <hr />
      <nameContext.Provider value={"Rinkesh"}>
        <surnameContext.Provider value={"Ranpariya"}>
          <ChildA />
        </surnameContext.Provider>
      </nameContext.Provider>
    </>
  );
}

export default Context;
