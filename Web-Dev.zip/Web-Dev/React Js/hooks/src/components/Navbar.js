import React from "react";
import { Link } from "react-router-dom";

function Navbar({isDark,func}) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <Link className="navbar-brand" to="/">
        Hooks
      </Link>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/home">
              Home
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/useState">
              useState
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/useEffect">
              useEffect
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/useContext">
              useContext
            </Link>
          </li>

          <li className="nav-item dropdown">
            <Link
              className="nav-link dropdown-toggle"
              to=""
              id="navbarDropdown"
              role="button"
              data-toggle="dropdown"
              aria-expanded="false"
            >
              useReducer
            </Link>
            <div className="dropdown-menu" aria-labelledby="navbarDropdown">
              <Link className="dropdown-item" to="/simpleUseReducer">
                Simple useReducer
              </Link>
              <Link className="dropdown-item" to="/complexUseReducer">
                complex useReducer
              </Link>
              <Link className="dropdown-item" to="/httpReducer">
                Http Reducer
              </Link>
            </div>
          </li>

          <li className="nav-item">
            <Link className="nav-link" to="/useCallback">
              useCallback
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/useMemo">
              useMemo
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/useRef">
              useRef
            </Link>
          </li>
        </ul>
        <button type="button" className="btn btn-light" onClick={func}>
            {isDark?"Light Mode":"Dark Mode"}
          </button>
      </div>
    </nav>
  );
}

export default Navbar;
