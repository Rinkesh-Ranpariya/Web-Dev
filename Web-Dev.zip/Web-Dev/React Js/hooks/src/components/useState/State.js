import React, { useState } from "react";

function State({isDark}) {
  const [count, setCount] = useState(0);
  const [detail, setDetail] = useState({ name: "", surname: "",designation:"" });
  const [data, setData] = useState([]);

  const handlerSubmit = (e) => {
    e.preventDefault();
    alert(`Hello ${detail.name} ${detail.surname} 👋`);
    setData([...data, detail]);
    setDetail({ name: "", surname: "",designation:"" });
  };

  const handlerInputChange = (e) => {
    setDetail({ ...detail, [e.target.name]: e.target.value });
  };

  return (
    <>
      <h1>useState Hook🪝</h1>
      <hr />

      <h4 className="mt-5">{count}</h4>
      <button
        onClick={() => setCount(count + 1)}
        className="btn btn-primary mt-2"
      >
        Increment
      </button>

      <h3 className="mt-5">Fill the form 👇</h3>
      <form
        className="mt-3 mx-auto"
        onSubmit={handlerSubmit}
        style={{ width: "40%"}}
        autoComplete="off"
      >
        <div className="form-group">
          <label htmlFor="textName">Name</label>
          <input
            type="text"
            value={detail.name}
            className="form-control"
            id="textName"
            name="name"
            onChange={handlerInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="textSurname">Surname</label>
          <input
            type="text"
            value={detail.surname}
            className="form-control"
            id="textSurname"
            name="surname"
            onChange={handlerInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="textDesignation">Designation</label>
          <input
            type="text"
            value={detail.designation}
            className="form-control"
            id="textDesignation"
            name="designation"
            onChange={handlerInputChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>

      <h3 className="mt-5">Your Detail</h3>
      <table
        className="table mx-auto"
        style={{ width: "80%",color:isDark?"white":"black" }}
      >
        <thead className="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Surname</th>
            <th scope="col">Designation</th>
          </tr>
        </thead>

        <tbody>
          {data.map((ele, index) => (
            <tr key={index}>
              <th scope="row">{index+1}</th>
              <td>{ele.name}</td>
              <td>{ele.surname}</td>
              <td>{ele.designation}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {data.length===0 ?<h3>"Please Enter Your Record !"</h3>:null}
    </>
  );
}

export default State;
