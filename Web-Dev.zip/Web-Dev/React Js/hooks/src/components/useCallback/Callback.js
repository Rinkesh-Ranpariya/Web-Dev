import React, { useCallback, useState } from "react";
import Button from "./Button";
import Count from "./Count";
import Title from "./Title";

function Callback() {
  const [age, setAge] = useState(21);
  const [salary, setSalary] = useState(50000);

  const valueIncrementAge = useCallback(() => {
    setAge(age + 1);
  }, [age]);

  const valueIncrementSalary = useCallback(() => {
    setSalary(salary + 2000);
  },[salary]) 

  return (
    <>
      <Title/>
      <hr />
      <Count type="Age" value={age} />
      <Button value={valueIncrementAge}>Age Increment</Button>
      <Count type="Salary" value={salary} />
      <Button value={valueIncrementSalary}>salary Increment</Button>
    </>
  );
}

export default Callback;
