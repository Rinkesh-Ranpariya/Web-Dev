import React from 'react'

function Button({value,children}) {
    console.log(`${children}`);
  return (
    <button onClick={value} className='btn btn-success mt-2'>{children}</button>
  )
}

export default React.memo(Button)