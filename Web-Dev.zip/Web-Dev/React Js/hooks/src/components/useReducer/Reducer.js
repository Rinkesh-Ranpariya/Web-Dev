import React, { useReducer } from "react";

const initialValue = 0;
const reducer = (state, action) => {
  switch (action) {
    case "increment":
      return state + 1;
    case "decrement":
      return state - 1;
    case "reset":
      return initialValue;
    default:
      return state;
  }
};

function Reducer() {
  const [state, dispatch] = useReducer(reducer, initialValue);

  return (
    <>
      <h1>useReducer Hook🪝</h1>
      <hr />
      <h3 className="mt-5">Simple State and action</h3>
      <h4 className="mt-3">Counter - {state}</h4>
      <button
        onClick={() => dispatch("increment")}
        className="btn btn-success mr-2 mt-4"
      >
        Increment
      </button>
      <button
        onClick={() => dispatch("decrement")}
        className="btn btn-success mx-2 mt-4"
      >
        Decrement
      </button>
      <button
        onClick={() => dispatch("reset")}
        className="btn btn-success ml-2 mt-4"
      >
        Reset
      </button>
    </>
  );
}

export default Reducer;
