import React, { useReducer } from 'react'

const initialValue = {
    counterOne:0
};
const reducer = (state, action) => {
  switch (action.type) {
    case "increment":
      return {counterOne:state.counterOne + action.value};
    case "decrement":
      return {counterOne:state.counterOne - action.value};
    case "reset":
      return initialValue;
    default:
      return state;
  }
};

function ComplexReducer() {
    const [state, dispatch] = useReducer(reducer, initialValue);

    return (
      <>
        <h1>useReducer Hook🪝</h1>
        <hr />
        <h3 className="mt-5">Complex State and action</h3>
        <h4 className="mt-3">Counter - {state.counterOne}</h4>
        <button
          onClick={() => dispatch({type:"increment",value:20})}
          className="btn btn-success mr-2 mt-4"
        >
          Increment
        </button>
        <button
          onClick={() => dispatch({type:"decrement",value:10})}
          className="btn btn-success mx-2 mt-4"
        >
          Decrement
        </button>
        <button
          onClick={() => dispatch({type:"reset"})}
          className="btn btn-success ml-2 mt-4"
        >
          Reset
        </button>
      </>
    );
}

export default ComplexReducer