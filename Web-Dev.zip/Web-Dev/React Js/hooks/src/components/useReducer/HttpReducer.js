import axios from "axios";
import React, { useEffect, useReducer } from "react";

const initialValue = {
  loading: true,
  post: [],
  error: "",
};
const reducer = (state, action) => {
  switch (action.type) {
    case "success":
      return {
        loading: false,
        post: action.data,
        error: "",
      };
    case "error":
      return {
        loading: false,
        post: [],
        error: "Somthing Went Wrong !",
      };
    default:
      return state;
  }
};

function HttpReducer({ isDark }) {
  const [state, dispatch] = useReducer(reducer, initialValue);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => dispatch({ type: "success", data: res.data }))
      .catch((err) => dispatch({ type: "error" }));
  }, []);

  return (
    <>
      <h1>useReducer Hook🪝</h1>
      <hr />
      <h3 className="my-5">Http - Fetch Data</h3>
      {state.loading ? (
        "Loading..."
      ) : (
        <table
          className="table mx-auto"
          style={{ width: "80%", color: isDark ? "white" : "black" }}
        >
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Title</th>
              <th scope="col">Body</th>
            </tr>
          </thead>
          <tbody>
            {state.post.map((ele) => (
              <tr key={ele.id}>
                <th scope="row">{ele.id}</th>
                <td>{ele.title}</td>
                <td>{ele.body}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {state.error ? <h3>{state.error}</h3> : null}
    </>
  );
}

export default HttpReducer;
