import React, { Component } from "react";
import "../css/main.css";

export class Main extends Component {
  render() {
    const { languageName, darkMode } = this.props;

    let style = {
      backgroundColor: darkMode ? "gray" : "white",
    };

    return (
      <div className="parent">
        <div className="child" style={style}>
          {languageName}
        </div>
      </div>
    );
  }
}

export default Main;
