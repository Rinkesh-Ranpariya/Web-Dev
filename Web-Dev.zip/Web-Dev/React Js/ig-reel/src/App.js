import './App.css';
import VideoCard from "./VideoCard"
import { useState,useEffect } from "react";
import db from './firebase'

function App() {

  const [reels, setReels] = useState([]);

  useEffect(() => {
    
    db.collection('reels').onSnapshot(snapshot=>(
      setReels(snapshot.docs.map(doc=>doc.data()))
    ))
    
  }, [])

  return (
    <div className="app">
      {/* <h1>jay swaminarayan</h1> */}
      {/* <div className="app_top">
        <img className="app_logo" src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="image" />
        <h2>Reels</h2>
      </div> */}

      <div className="app_videos">
        {reels.map(reel=>(

        <VideoCard 

          channel={reel.channel}
          avatarSrc={reel.avatarSrc}
          song={reel.song.toString().substring(0, 12)}
          url={reel.url}
          likes={reel.likes}
          shares={reel.shares}

          // channel='rrr'
          // avatarSrc='p'
          // song='s'
          // url='u'
          // likes={100}
          // shares={60}

        />

        ))}
        
      </div>

    </div>
  );
}

export default App;
