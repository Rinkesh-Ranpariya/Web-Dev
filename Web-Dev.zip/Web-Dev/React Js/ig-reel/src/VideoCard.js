import React, { useRef,useState } from "react";
import "./VideoCard.css";
import VideoHeader from "./VideoHeader"
import VideoFooter from "./VideoFooter"


function VideoCard({channel,avatarSrc,song,url,likes,shares}) {

    const [isVideoPlaying, setIsVideoPlaying] = useState(false)
    const videoRef = useRef(null); //pointer

    const onVideoPress=()=>{
        if(isVideoPlaying){          //for stop
            videoRef.current.pause();
            setIsVideoPlaying(false);
        }
        else{
            videoRef.current.play();   //for play
            setIsVideoPlaying(true);
        }
    }

  return (
    <div className="videoCard">
        <VideoHeader/>
      <img
        ref={videoRef}
        // onClick={onVideoPress}
        className="videoCard_player"
        src={url}
        alt="video"
        loop
      />
        <VideoFooter
        
          channel={channel}
          avatarSrc={avatarSrc}
          song={song}          
          likes={likes}
          shares={shares}
        
        />
      {/* <h2 className="videoCard_player">hey</h2> */}
    </div>
  );
}

export default VideoCard;
