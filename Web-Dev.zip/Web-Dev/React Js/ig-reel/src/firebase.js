// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import firebase from 'firebase'

const firebaseConfig = {
    apiKey: "AIzaSyB4YsL9fFR-xB2Xiz9UqdVRYbWZvghxuS8",
    authDomain: "ig-reels-fae98.firebaseapp.com",
    projectId: "ig-reels-fae98",
    storageBucket: "ig-reels-fae98.appspot.com",
    messagingSenderId: "67011265736",
    appId: "1:67011265736:web:cd57bc528c2d46e7d091fd",
    measurementId: "G-X0GQYCBYWF"
  };

const firebaseApp=firebase.initializeApp(firebaseConfig);

const db=firebaseApp.firestore();

export default db;