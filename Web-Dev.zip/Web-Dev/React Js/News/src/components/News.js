import React, { Component } from 'react'
import NewsItem from './NewsItem'

export class News extends Component {
            
    constructor(){
        super();
        this.state={
            artical:[],
            page:1,
            loading:false
        }
    }

    async componentDidMount(){

        let url=`https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=7f105c672f47459a9d1e76d1f8286c63&page=${this.state.page}&pageSize=18`

        let data = await fetch(url)
        let jsondata = await data.json()
        console.log(jsondata)
        this.setState({
            artical:jsondata.articles,
            totalResults:jsondata.totalResults
        })

    }

    handlePrev = async ()=>{
        let url=`https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=7f105c672f47459a9d1e76d1f8286c63&page=${this.state.page-1}&pageSize=18`

        let data = await fetch(url)
        let jsondata = await data.json()

        this.setState({
            artical:jsondata.articles,
            page:this.state.page-1
        })
    }

    handleNext = async ()=>{
        let url=`https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=7f105c672f47459a9d1e76d1f8286c63&page=${this.state.page+1}&pageSize=18`

        let data = await fetch(url)
        let jsondata = await data.json()

        this.setState({
            artical:jsondata.articles,
            page:this.state.page+1
        })
    }

    render() {
        return (
            <div className="container my-4">
                <h2 className="text-center" style={{margin:"40px"}}>NewsMonkey - Top Headlines</h2>
                <div className="row">
                    
                    {
                        this.state.artical.map(ele => {
                            return ele.title && ele.description && ele.urlToImage && ele.url && <div className="col-md-4 mb-4" key={ele.url}>
                                <NewsItem title={ele.title} des={ele.description} imgurl={ele.urlToImage} url={ele.url}/>
                            </div>
                        })
                    }    
                    
                </div>
                <div className="container d-flex justify-content-between">
                    <button disabled={this.state.page===1} onClick={this.handlePrev} type="button" className="btn btn-dark">Previous</button>
                    <button disabled={this.state.page === Math.ceil(this.state.totalResults/18)} onClick={this.handleNext} type="button" className="btn btn-dark">Next</button>
                </div>
            </div>
        )
    }
}

export default News
