import './App.css';
import Navbar from './components/Navbar';
import Text from './components/Text';
import React,{useState} from "react";
import Popup from './components/Popup';

function App() {

  const [colorr, setColorr] = useState({
    color:'black',
    backgroundColor:'white'
  })
  
  const handle=()=>{
    if(colorr.color==='black'){
      setColorr({
        color:'white',
        backgroundColor:'black'
      })
      document.body.style.backgroundColor="black";
      pop("success","Dark Mode Enabled")
    }
    else{
      setColorr({
        color:'black',
        backgroundColor:'white'
      })
      document.body.style.backgroundColor="white";
      pop("success","Dark Mode Disabled")
    }
  }

  const [popups, setPopups] = useState(null)

  const pop =(a,m)=>{
    setPopups({
      alert:a,
      mess:m
    })

    setTimeout(() => {
      setPopups(null)
    }, 2000);
  }

  // const ma1={
  //   color:'white',
  //   backgroundColor:'black'
  // }

  // const ma2={
  //   color:'black',
  //   backgroundColor:'white'
  // }

  return (
    <div className="App">
      <Navbar handle={handle}/>
      <Popup fun={popups} />

      <div style={colorr}>
        <Text c={colorr} fun={pop}/>
      </div>
    </div>
  );
}

export default App;