import React,{useState} from "react";

function Text(props) {

    const [input, setInput] = useState('');

    const UpperCase = (e)=>{
        e.preventDefault();
        let toupper=input.toUpperCase();
        setInput(toupper)
        props.fun("success","Text is Transformed in Uppercase")
      }
      
      const LowerCase = (e)=>{
        e.preventDefault();
        let tolower=input.toLowerCase();
        setInput(tolower)
        props.fun("success","Text is Transformed in Lowercase")
      }
      
      const Remove = (e)=>{
        e.preventDefault();
        let remove=input.trim().split(/[" "]+/);
        setInput(remove.join(" "))
        props.fun("success","Extra Space Removed From Text")
      }

      const Clear = (e)=>{
        e.preventDefault();
        setInput('')
        props.fun("success","Text is Cleared")
    }

    let co={
        color:props.c.color,
        backgroundColor:props.c.backgroundColor
    }

  // let i1=input.trim().split(/[" "]+/);
  let i1=input.trim().split(/\s+/);
  let i2=i1.join("").length
  let i3=i1.join(" ")
  
  return (
    <div className="container py-3">
      <form>
        <div className="form-group">
          <h3>Enter Your Text Here...</h3>
          <textarea
            style={co}
            className="form-control"
            id="exampleFormControlTextarea1"
            rows="6"
            value={input}
            onChange={e => {setInput(e.target.value)}}
          ></textarea>
        </div>
        <button type="button" disabled={!input} className="btn btn-success my-1 mx-1" onClick={UpperCase}>Upper Case</button>
        <button type="button" disabled={!input} className="btn btn-success my-1 mx-1" onClick={LowerCase}>Lower Case</button>
        <button type="button" disabled={!input} className="btn btn-success my-1 mx-1" onClick={Remove}>Remove Extra Space</button>
        <button type="button" disabled={!input} className="btn btn-success my-1 mx-1" onClick={Clear}>Clear</button>
      </form>

        <div className="my-3">
            <h3>Analysed Text...</h3>

            <p>words : {i1.filter( ele => {return ele.length!==0}).length}</p>
            <p>chars : {i2}</p>
            <p>Final Text : {!i3 ? "Nothing to Show" : i3}</p>
        </div>

    </div>
  );
}

export default Text;