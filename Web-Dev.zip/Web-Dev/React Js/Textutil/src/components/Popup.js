import React from "react";

function Popup({fun}) {
  return (

    <div style={{height:"50px"}}>
      {fun && (<div>
        <div className={`alert alert-${fun.alert} alert-dismissible fade show`} role="alert" style={{margin:"0px"}}>
          <strong>{fun.alert} !!!</strong>   {fun.mess}...
          {/* <button
            type="button"
            className="btn-close"
            data-bs-dismiss="alert"
            aria-label="Close"
          ></button> */}
        </div>
      </div>)}
    </div>
  );
}

export default Popup;