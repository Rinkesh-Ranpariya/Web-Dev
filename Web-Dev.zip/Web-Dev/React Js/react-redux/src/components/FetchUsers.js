import React, { useEffect } from "react";
import { connect } from "react-redux";
import { fetchUsers } from "../redux";

function FetchUsers({ user, fetchUsers }) {
  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div>
      <h1>FetchUsers</h1>
      {user.loading ? (
        "Loading..."
      ) : user.error ? (
        <h1>{user.error}</h1>
      ) : (
        user.data &&
        user.data.map((userObj) => <p key={userObj.id}>{userObj.title}</p>)
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    user: state.users,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    fetchUsers: () => dispatch(fetchUsers()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(FetchUsers);
