import React from "react";
import { connect } from "react-redux";
import { buyIcecream } from "../redux";

function IceCreamContainer({ numberOfIcecream, buyIcecream }) {
  return (
    <div>
      <h1>IceCreamContainer</h1>
      <div>Icecream - {numberOfIcecream}</div>
      <button onClick={buyIcecream} className="btn btn-primary">
        Buy Icecream
      </button>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    numberOfIcecream: state.iceCream.numberOfIcecream,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    buyIcecream: () => dispatch(buyIcecream()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(IceCreamContainer);
