import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { buyCake } from "../redux";

function HookCakeContainer() {
  const numberOfCake = useSelector((state) => state.cake.numberOfCake);
  const dispatch = useDispatch();

  return (
    <div>
      <h1>HookCakeContainer</h1>
      <div>Cake - {numberOfCake}</div>
      <button onClick={() => dispatch(buyCake())} className="btn btn-primary">
        Buy Cake
      </button>
    </div>
  );
}

export default HookCakeContainer;
