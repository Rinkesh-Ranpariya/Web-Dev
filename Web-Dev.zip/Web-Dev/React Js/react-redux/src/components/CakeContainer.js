import React, { useState } from "react";
import { connect } from "react-redux";
import { buyCake } from "../redux";

function CakeContainer({ numberOfCake, buyCake }) {
  const [cake, setCake] = useState(1);
  return (
    <div>
      <h1>CakeContainer</h1>
      <div>Cake - {numberOfCake}</div>
      <input
        type="text"
        value={cake}
        onChange={(e) => setCake(e.target.value)}
      />
      <button onClick={() => buyCake(cake)} className="btn btn-primary">
        Buy {cake} Cake
      </button>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    numberOfCake: state.cake.numberOfCake,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    buyCake: (cake) => dispatch(buyCake(cake)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CakeContainer);
