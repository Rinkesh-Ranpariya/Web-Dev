export const BUY_ICECREAM = "BUY_ICECREAM";
