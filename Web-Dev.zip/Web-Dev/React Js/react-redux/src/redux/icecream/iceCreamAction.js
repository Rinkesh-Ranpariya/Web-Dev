import { BUY_ICECREAM } from "./iceCreamType";

export const buyIcecream = () => {
  return {
    type: BUY_ICECREAM,
  };
};
