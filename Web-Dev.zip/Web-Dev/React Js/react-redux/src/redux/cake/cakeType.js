export const BUY_CAKE = "BUY_CAKE";
