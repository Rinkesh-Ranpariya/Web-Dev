import { Provider } from "react-redux";
import "./App.css";
import CakeContainer from "./components/CakeContainer";
import FetchUsers from "./components/FetchUsers";
import HookCakeContainer from "./components/HookCakeContainer";
import IceCreamContainer from "./components/IceCreamContainer";
import store from "./redux/store";

function App() {
  return (
    <Provider store={store}>
      <div className="App mt-5">
        <CakeContainer />
        <HookCakeContainer />
        <IceCreamContainer />
        <FetchUsers />
      </div>
    </Provider>
  );
}

export default App;
