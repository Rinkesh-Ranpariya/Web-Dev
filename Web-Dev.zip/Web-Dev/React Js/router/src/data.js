let courses = [
  {
    name: "ReactJs",
    number: 1,
    amount: "$800",
    img: "https://patoliyainfotech.com/wp-content/uploads/2019/10/one-year-of-react-native-705x397.png",
  },
  {
    name: "ReactNative",
    number: 3,
    amount: "$500",
    img: "https://www.appcoda.com/wp-content/uploads/2015/04/react-native.png",
  },
  {
    name: "Vue",
    number: 2,
    amount: "$200",
    img: "https://segwitz.com/wp-content/uploads/2021/06/vuejs-development-malaysia.jpeg",
  },
  {
    name: "Django",
    number: 4,
    amount: "$400",
    img: "https://i0.wp.com/www.skysilk.com/blog/wp-content/uploads/2017/11/python-django-logo.jpg?fit=860%2C440&ssl=1",
  },
];

export function getCourses() {
  return courses;
}
