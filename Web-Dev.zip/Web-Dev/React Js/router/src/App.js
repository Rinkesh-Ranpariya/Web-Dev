import "./App.css";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import About from "./components/About";
import Courses from "./components/Courses";
import Course from "./components/Course";
import Dashbord from "./components/Dashbord";
import Login from "./components/Login";
import Logout from "./components/Logout";
import Error from "./components/Error";
import { Authentication } from "./components/Authentication";
import RequirAuth from "./components/RequirAuth";
import CoursePage from "./components/CoursePage";
import Footer from "./components/Footer";
import { useState } from "react";
import Purchase from "./components/Purchase";

function App() {
  /* <h1>jsk</h1> */

  const [isDark, setIsDark] = useState(false);

  const changeMode = () => {
    setIsDark(!isDark);
  };

  return (
    <Authentication>
      <div className={`App ${isDark ? "dark" : "light"}`}>
        <Routes>
          <Route
            path="/"
            element={<Navbar isDark={isDark} changeMode={changeMode} />}
          >
            <Route index element={<Home />} />
            <Route path="about" element={<About isDark={isDark} />} />
            <Route path="courses" element={<CoursePage />}>
              <Route index element={<Courses isDark={isDark} />} />
              <Route path=":course" element={<Course isDark={isDark} />} />
            </Route>
            <Route
              path="dashbord"
              element={
                <RequirAuth>
                  <Dashbord isDark={isDark} />
                </RequirAuth>
              }
            />
            <Route path="purchase" element={<Purchase />} />
            <Route path="login" element={<Login />} />
            <Route path="logout" element={<Logout />} />
            <Route path="*" element={<Error />} />
          </Route>
        </Routes>
      </div>
      <Footer />
    </Authentication>
  );
}

export default App;
