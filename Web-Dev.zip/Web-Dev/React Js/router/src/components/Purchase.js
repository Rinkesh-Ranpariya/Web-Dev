import React from "react";

function Purchase() {
  return <h1 className="mt-5">Purchase</h1>;
}

export default Purchase;
