import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "./Authentication";
import { getCourses } from "../data";
import { Link } from "react-router-dom";

function Dashbord({ isDark }) {
  let courses = getCourses();
  let navigate = useNavigate();
  const auth = useAuth();

  let data = {
    msg: "Thank-you for visiting us !",
  };

  const handleLogout = () => {
    auth.logout();
    navigate("/logout", { state: data }, { replace: true });
  };

  return (
    <div className="pb-5">
      <h1 className="mt-5">Dashbord</h1>
      <button onClick={handleLogout} className="btn btn-outline-danger">
        Logout
      </button>
      <h4 className="mt-5">Your Courses is here...</h4>

      <div className="container">
        <div className="container-fluid">
          <div className="row">
            {courses.map(
              (course, index) =>
                index < 3 && (
                  <div
                    className="card"
                    key={course.number}
                    style={{ width: "18rem", margin: "10px 20px" }}
                  >
                    <img src={course.img} className="card-img-top" alt="..." />
                    <div className={`card-body ${isDark ? "dark" : "light"}`}>
                      <h3 className="card-title">{course.name}</h3>
                      <p className="card-text">
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content.
                      </p>
                      <h4 className="card-text">{course.amount}</h4>
                      <Link to="/purchase" className="btn btn-primary">
                        Purchase
                      </Link>
                    </div>
                  </div>
                )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashbord;
