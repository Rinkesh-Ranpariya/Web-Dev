import React from "react";
import "./Coin.css";

const Coin = ({ name, image, symbol, marketcap, price, pricechange }) => {
  return (
    <tr>
      <td>
        <img src={image} alt="crypto" />
        {name}
      </td>
      <td className="coin-symbol">{symbol}</td>
      <td>Rs.{price}</td>
      {pricechange < 0 ? (
        <td className="red">{pricechange.toFixed(2)}%</td>
      ) : (
        <td className="green">{pricechange.toFixed(2)}%</td>
      )}
      <td>Mkt Cap: Rs.{marketcap.toLocaleString()}</td>
    </tr>
  );
};

export default Coin;
