import "./App.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import Coin from "./components/Coin";

function App() {
  const [coins, setCoins] = useState([]);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  useEffect(() => {
    axios
      .get(
        "https://api.coingecko.com/api/v3/coins/markets?vs_currency=INR&order=market_cap_desc&per_page=100&page=1&sparkline=false"
      )
      .then((res) => setCoins(res.data))
      .catch((error) => setError("Somthing Went Wronge !!!"));
  }, []);

  const handleChange = (e) => {
    setSearch(e.target.value);
  };

  const filteredCoins = coins.filter((coin) =>
    coin.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="coin-app">
      <div className="coin-search">
        <h1 className="text-white mb-5">Crypto Tracker</h1>
        <form>
          <input
            type="text"
            className="coin-input"
            placeholder="Provide the coin name"
            onChange={handleChange}
          />
        </form>
      </div>
      {coins.length > 0 ? (
        <table className="table table-dark mx-auto" style={{ maxWidth: "80%" }}>
          <thead>
            <tr>
              <th scope="col">Image Name</th>
              <th scope="col">Symbol</th>
              <th scope="col">Price</th>
              <th scope="col">Pricechange</th>
              <th scope="col">Marketcap</th>
            </tr>
          </thead>
          <tbody>
            {filteredCoins.map((coin) => {
              return (
                <Coin
                  key={coin.id}
                  name={coin.name}
                  image={coin.image}
                  symbol={coin.symbol}
                  marketcap={coin.market_cap}
                  price={coin.current_price}
                  pricechange={coin.price_change_percentage_24h}
                />
              );
            })}
          </tbody>
        </table>
      ) : null}
      {error ? <h1 style={{ color: "white" }}>{error}</h1> : null}
    </div>
  );
}

export default App;
