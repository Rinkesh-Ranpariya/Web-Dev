import React from "react";

function TableHead() {
  return (
    <thead className="thead-dark">
      <tr>
        <th>Id</th>
        <th>image</th>
        <th>title</th>
        <th>price</th>
        <th>category</th>
        <th>description</th>
        <th>rating</th>
        <th>operations</th>
      </tr>
    </thead>
  );
}

export default TableHead;
