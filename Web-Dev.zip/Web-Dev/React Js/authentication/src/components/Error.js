import React from "react";
import { useNavigate } from "react-router-dom";

function Error() {
  const navigate = useNavigate();

  const handleGoback = () => {
    navigate(-1);
  };

  return (
    <>
      <h1 className="mt-5">404 Page Not Found !!!</h1>
      <button
        type="submit"
        className="mt-5 btn btn-primary"
        onClick={handleGoback}
      >
        Go Back
      </button>
    </>
  );
}

export default Error;
