import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Login() {
  const location = useLocation();
  const navigate = useNavigate();

  const [user, setUser] = useState("");

  const handleLogin = (e) => {
    setUser(e.target.value);
  };

  const path = location.state || "/";

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem("user", user);
    navigate(path);
    setUser("");
  };

  return (
    <>
      <h1 className="mt-5">Login</h1>
      {!localStorage.getItem("user") ? (
        <form
          autoComplete="off"
          onSubmit={handleSubmit}
          style={{ width: "250px" }}
          className="mx-auto mt-5"
        >
          <div className="form-group">
            <label htmlFor="user">User Name :</label>
            <input
              type="text"
              className="form-control"
              id="user"
              value={user}
              onChange={handleLogin}
            />
          </div>

          <button
            type="submit"
            disabled={!user}
            className="btn btn-outline-success"
          >
            Login
          </button>
        </form>
      ) : (
        <h2>You are Logedin !</h2>
      )}
    </>
  );
}

export default Login;
