import "./App.css";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import About from "./components/About";
import Login from "./components/Login";
import Logout from "./components/Logout";
import Error from "./components/Error";
import RequirAuth from "./components/RequirAuth";
import Footer from "./components/Footer";
import Formik from "./components/Formik";

function App() {
  return (
    <>
      <div className="App">
        <Routes>
          <Route path="/" element={<Navbar />}>
            <Route index element={<Home />} />
            <Route
              path="about"
              element={
                <RequirAuth>
                  <About />
                </RequirAuth>
              }
            />
            <Route path="login" element={<Login />} />
            <Route path="logout" element={<Logout />} />
            <Route path="formik" element={<Formik />} />
            <Route path="*" element={<Error />} />
          </Route>
        </Routes>
      </div>
      <Footer />
    </>
  );
}

export default App;
