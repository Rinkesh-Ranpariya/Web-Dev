export let secretButton = document.querySelector('#secret-button');
export let secretParagraph = document.querySelector('#secret-paragraph');
