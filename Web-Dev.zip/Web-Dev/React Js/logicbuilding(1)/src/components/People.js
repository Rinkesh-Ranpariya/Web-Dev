import axios from "axios";
import React, { useEffect, useState } from "react";
import Pagination from "./Pagination";
import CardUi from "./CardUi";
import Gender from "./Gender";
import SortById from "./SortById";
import Input from "./Input";

function People() {
  //state -------------------------------------------------------------
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(6);

  const [input, setInput] = useState("");
  const [gender, setGender] = useState("all");
  const [sortById, setSortById] = useState("Asc");

  //api call ----------------------------------------------------------------
  useEffect(() => {
    axios
      .get("https://fakerapi.it/api/v1/persons")
      .then((res) => {
        setData(res.data.data);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  //search filter ----------------------------------------------------------------
  let mainData =
    gender === "male"
      ? data.filter((ele) => {
          if (ele.gender === "male") {
            return true;
          }
        })
      : gender === "female"
      ? data.filter((ele) => {
          if (ele.gender === "female") {
            return true;
          }
        })
      : gender === "all"
      ? data.filter((ele) => {
          return true;
        })
      : data;

  mainData =
    sortById === "Asc"
      ? mainData.sort((a, b) => {
          return a.id - b.id;
        })
      : sortById === "Desc"
      ? mainData.sort((a, b) => {
          return b.id - a.id;
        })
      : mainData;

  mainData = input
    ? mainData.filter((ele) => {
        let flag = false;
        for (let item of Object.values(ele)) {
          let itemLowerCaseString = String(item).toLowerCase();
          if (itemLowerCaseString.includes(input)) {
            flag = true;
            break;
          }
        }
        if (flag === true) {
          return true;
        } else {
          return false;
        }
      })
    : mainData;

  //handleClick --------------------------------------------------------------
  const handleInput = (e) => {
    setInput(e.target.value.toLowerCase());
  };

  const handleClickSortById = (e) => {
    setSortById(e.target.value);
  };

  const handleGenderFilter = (e) => {
    setGender(e.target.value);
  };

  //Number Of Different Type Email --------------------------------------------------
  let numberOfDifferentTypeEmail = mainData.reduce((ansObject, ele) => {
    const emailType = ele.email.split("@")[1];
    ansObject[emailType] = (ansObject[emailType] || 0) + 1;
    return ansObject;
  }, {});

  // Get current posts ---------------------------------------------------------------
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = mainData.slice(indexOfFirstPost, indexOfLastPost);

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="">
      <Input handleInput={handleInput} />
      <Gender handleGenderFilter={handleGenderFilter} />
      <SortById handleClickSortById={handleClickSortById} />

      <div className="m-5">
        {Object.keys(numberOfDifferentTypeEmail).map((key) => {
          return (
            <span className="m-4">
              {key} : {numberOfDifferentTypeEmail[key]}
            </span>
          );
        })}
      </div>

      <div className="d-flex justify-content-center align-items-center mt-5">
        <div className="container row">
          {loading ? (
            "loading..."
          ) : error ? (
            <h3>{error}</h3>
          ) : (
            currentPosts.map((ele) => <CardUi key={ele.id} profile={ele} />)
          )}
        </div>
      </div>
      <Pagination
        postsPerPage={postsPerPage}
        totalPosts={mainData.length}
        paginate={paginate}
      />
    </div>
  );
}

export default People;
