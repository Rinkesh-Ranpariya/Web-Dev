import "./App.css";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Navbar from "./components/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import People from "./components/People";
import PeopleData from "./components/PeopleData";
import Profile from "./components/Profile";

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="routes">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/people" element={<PeopleData />}>
            <Route index element={<People />} />
            <Route path="id" element={<Profile />} />
          </Route>
        </Routes>
      </div>
    </div>
  );
}

export default App;

// https://fakerapi.it/api/v1/persons
// https://pokeapi.co/api/v2/pokemon

// //1.Filtering
// //2.Sorting
// //3.Searching
// //4.pagination with slice
// 5.map, filter, forEach, reduce
// //6.routing
// //7.reusibility
