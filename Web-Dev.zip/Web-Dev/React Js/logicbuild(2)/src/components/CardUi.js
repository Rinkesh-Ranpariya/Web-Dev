import React from "react";
import CommonCard from "./CommonCard";

function CardUi({ profile }) {
  return <CommonCard profile={profile} btn="false" />;
}

export default CardUi;
