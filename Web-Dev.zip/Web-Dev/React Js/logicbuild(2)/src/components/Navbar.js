import React from "react";
import { Link, NavLink } from "react-router-dom";

function Navbar() {
  return (
    <nav className="nav navbar navbar-expand-lg navbar-dark bg-dark">
      <Link className="navbar-brand" to="/">
        Logic
      </Link>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <NavLink
              className="nav-link"
              to="/"
              style={({ isActive }) => ({
                backgroundColor: isActive ? "#686de0" : "",
                borderRadius: "15px",
              })}
            >
              Home
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink
              className="nav-link"
              to="/people"
              style={({ isActive }) => ({
                backgroundColor: isActive ? "#686de0" : "",
                borderRadius: "15px",
              })}
            >
              People
            </NavLink>
          </li>

          {/* <li className="nav-item">
            <NavLink
              className="nav-link"
              to="/login"
              style={({ isActive }) => ({
                backgroundColor: isActive ? "#686de0" : "",
                borderRadius: "15px",
              })}
            >
              Login
            </NavLink>
          </li>

          <li className="nav-item">
            <NavLink
              className="nav-link"
              to="/logout"
              style={({ isActive }) => ({
                backgroundColor: isActive ? "#686de0" : "",
                borderRadius: "15px",
              })}
            >
              Logout
            </NavLink>
          </li> */}
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;
