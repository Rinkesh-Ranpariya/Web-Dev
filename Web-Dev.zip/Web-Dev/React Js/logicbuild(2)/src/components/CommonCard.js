import React, { useState } from "react";
import { Button, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function CommonCard({ profile, btn }) {
  const {
    id,
    firstname,
    lastname,
    email,
    phone,
    birthday,
    gender,
    address,
    website,
    image,
  } = profile;

  const navigate = useNavigate();
  const handleClickProfile = () => {
    navigate(`/people/id`, { state: { profile } });
  };

  return (
    <div
      className={`${
        btn === "false"
          ? "col-lg-4 col-md-6 col-sm-12 mt-2"
          : "d-flex justify-content-center"
      }`}
    >
      <Card style={{ width: btn === "false" ? "20rem" : "600px" }}>
        <Card.Img variant="top" src={image} />
        <Card.Body>
          <Card.Text>First name: {firstname}</Card.Text>
          <Card.Text>Second name: {lastname}</Card.Text>
          <Card.Text>Id : {id}</Card.Text>
          <Card.Text>Gender : {gender}</Card.Text>
          <Card.Text>Email : {email}</Card.Text>
          {btn === "true" ? (
            <>
              <Card.Text>phone : {phone}</Card.Text>
              <Card.Text>birthday : {birthday}</Card.Text>
              <Card.Text>street : {address.street}</Card.Text>
              <Card.Text>streetName : {address.streetName}</Card.Text>
              <Card.Text>city : {address.city}</Card.Text>
              <Card.Text>zipcode : {address.zipcode}</Card.Text>
              <Card.Text>country : {address.country}</Card.Text>
              <Card.Text>county_code : {address.county_code}</Card.Text>
              <Card.Text>website : {website}</Card.Text>
              <a href={website} target="_blank">
                <Button variant="primary">Website</Button>
              </a>
            </>
          ) : null}
          {btn === "false" ? (
            <Button variant="primary" onClick={() => handleClickProfile()}>
              View Profile
            </Button>
          ) : null}
        </Card.Body>
      </Card>
    </div>
  );
}

export default CommonCard;
