import React from "react";
import { Outlet } from "react-router-dom";

function PeopleData() {
  return <Outlet />;
}

export default PeopleData;
