import React from "react";
import { useLocation } from "react-router-dom";
import CommonCard from "./CommonCard";

function Profile() {
  const location = useLocation();

  return (
    <>
      <CommonCard profile={location.state.profile} btn="true" />
    </>
  );
}

export default Profile;
