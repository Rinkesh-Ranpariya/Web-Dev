import React from "react";

function SortById({ handleClickSortById }) {
  return (
    <div className="d-flex">
      <div>Sord By Id : </div>
      <div className="form-check mx-3">
        <input
          className="form-check-input"
          type="radio"
          name="flexRadioDefault"
          id="flexRadioDefault1"
          value="Asc"
          onChange={handleClickSortById}
        />
        <label className="form-check-label" htmlFor="flexRadioDefault1">
          Asc
        </label>
      </div>
      <div className="form-check">
        <input
          className="form-check-input"
          type="radio"
          name="flexRadioDefault"
          id="flexRadioDefault2"
          value="Desc"
          onChange={handleClickSortById}
        />
        <label className="form-check-label" htmlFor="flexRadioDefault2">
          Desc
        </label>
      </div>
    </div>
  );
}

export default SortById;
