import React from "react";

function Home() {
  return (
    <div className="home">
      <h1>Are You Looking For Great Profile !?</h1>
    </div>
  );
}

export default Home;
