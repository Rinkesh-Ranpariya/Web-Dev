import React from "react";
import { Form } from "react-bootstrap";

function Input({ handleInput }) {
  return (
    <div>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Search</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter value"
          onChange={handleInput}
        />
      </Form.Group>
    </div>
  );
}

export default Input;
