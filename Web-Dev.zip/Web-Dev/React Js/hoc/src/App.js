import ProductTable from "./components/ProductTable";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import "./App.css";
import PostTable from "./components/PostTable";

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<ProductTable />} />
        <Route path="/posts" element={<PostTable />} />
      </Routes>
    </>
  );
}

export default App;
