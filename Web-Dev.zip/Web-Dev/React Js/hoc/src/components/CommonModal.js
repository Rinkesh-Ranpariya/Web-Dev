import React from "react";
import { Button, Modal } from "react-bootstrap";

const CommonModal = ({ index, header, body, toggle, submitHandler, data }) => {
  let { id, image, title, price, category, description } = {
    ...data,
  };

  const handleClick = () => {
    submitHandler(index);
    toggle();
  };

  return (
    <>
      <Modal show={true} onHide={toggle}>
        <Modal.Header closeButton>
          <Modal.Title>{header}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={toggle}>
            Close
          </Button>
          <Button
            disabled={
              header === "Add Data" || header === "Edit Data"
                ? !id || !image || !title || !price || !category || !description
                : false
            }
            variant="primary"
            onClick={handleClick}
          >
            {header}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default CommonModal;
