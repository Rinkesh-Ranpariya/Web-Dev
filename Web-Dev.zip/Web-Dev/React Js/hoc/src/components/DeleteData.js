import React, { useState } from "react";
import { Button } from "react-bootstrap";
import CommonModal from "./CommonModal";

function DeleteData({ index, handlerDeleteData }) {
  const [isModalOpen, setIsOpenModal] = useState(false);

  const toggle = () => {
    setIsOpenModal(!isModalOpen);
  };
  return (
    <>
      <Button variant="danger" onClick={() => toggle()}>
        Delete
      </Button>
      {isModalOpen && (
        <CommonModal
          index={index}
          header={"Delete Data"}
          toggle={toggle}
          body={<h4>Are You Sure !!!</h4>}
          submitHandler={handlerDeleteData}
        />
      )}
    </>
  );
}

export default DeleteData;
