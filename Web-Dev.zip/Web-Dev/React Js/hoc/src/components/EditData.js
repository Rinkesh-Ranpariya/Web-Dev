import React, { useState } from "react";
import { Button } from "react-bootstrap";
import CommonModal from "./CommonModal";
import EditForm from "./EditForm";

const EditData = ({
  index,
  handleViewData,
  viewData,
  handlerChange,
  handlerSubmit,
}) => {
  const [isModalOpen, setIsOpenModal] = useState(false);

  const toggle = () => {
    setIsOpenModal(!isModalOpen);
    handleViewData(index);
  };

  return (
    <>
      <Button onClick={() => toggle()}>Edit</Button>
      {isModalOpen && (
        <CommonModal
          index={index}
          header={"Edit Data"}
          toggle={toggle}
          body={<EditForm viewData={viewData} handlerChange={handlerChange} />}
          submitHandler={handlerSubmit}
          data={viewData}
        />
      )}
    </>
  );
};

export default EditData;
