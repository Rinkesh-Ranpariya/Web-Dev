import React, { useEffect, useState } from "react";
import axios from "axios";
import AddData from "./AddData";
import EditData from "./EditData";
import TableHead from "./TableHead";
import DeleteData from "./DeleteData";
import CommonTable from "./CommonTable";

function ProductTable() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  const [viewData, setViewData] = useState({
    index: "",
    id: "",
    image: "",
    title: "",
    price: "",
    category: "",
    description: "",
  });

  const [addNewData, setAddNewData] = useState({
    index: "",
    id: "",
    image: "",
    title: "",
    price: "",
    category: "",
    description: "",
  });

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((res) => {
        setData(res.data);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  const handleViewData = (index) => {
    setViewData({
      index: index,
      id: data[index].id,
      image: data[index].image,
      title: data[index].title,
      price: data[index].price,
      category: data[index].category,
      description: data[index].description,
    });
  };

  const handlerViewDataChange = (e) => {
    setViewData({ ...viewData, [e.target.name]: e.target.value });
  };

  const handlerAddDataChange = (e) => {
    setAddNewData({ ...addNewData, [e.target.name]: e.target.value });
  };

  const handlerEditData = (index) => {
    data.splice(index, 1, viewData);
    setData([...data]);
  };

  const handlerAddNewData = () => {
    setData([addNewData, ...data]);
    setAddNewData({
      index: "",
      id: "",
      image: "",
      title: "",
      price: "",
      category: "",
      description: "",
    });
  };

  const handlerDeleteData = (index) => {
    data.splice(index, 1);
    setData([...data]);
  };

  return (
    <>
      <div className="d-flex justify-content-center my-4">
        <AddData
          type="add"
          viewData={addNewData}
          handlerChange={handlerAddDataChange}
          handlerSubmit={handlerAddNewData}
        />
      </div>
      {loading ? (
        "Loading..."
      ) : error ? (
        <h5>{error}</h5>
      ) : (
        <CommonTable
          type="prod"
          head={["id", "image", "title", "price", "category", "description"]}
          body={data.map((ele, index) => (
            <tr className="trData" key={ele.id}>
              <td>{ele.id}</td>
              <td>
                <img src={ele.image} alt="img" width="50px" height="50px" />
              </td>
              <td className="title">{ele.title}</td>
              <td>{ele.price}</td>
              <td>{ele.category}</td>
              <td>{ele.description}</td>
              <td>
                <EditData
                  type="edit"
                  viewData={viewData}
                  index={index}
                  handleViewData={handleViewData}
                  handlerChange={handlerViewDataChange}
                  handlerSubmit={handlerEditData}
                />
                <DeleteData
                  index={index}
                  handlerDeleteData={handlerDeleteData}
                />
              </td>
            </tr>
          ))}
        />
      )}
    </>
  );

  //   return (
  //     <>
  //       <div className="d-flex justify-content-center my-4">
  //         <AddData
  //           type="add"
  //           viewData={addNewData}
  //           handlerChange={handlerAddDataChange}
  //           handlerSubmit={handlerAddNewData}
  //         />
  //       </div>
  //       <table id="table" className="table">
  //         <TableHead />
  //         <tbody id="tableBody">
  //           {loading ? (
  //             "Loading..."
  //           ) : error ? (
  //             <h5>{error}</h5>
  //           ) : (
  //             data.map((ele, index) => (
  //               <tr className="trData" key={ele.id}>
  //                 <td>{ele.id}</td>
  //                 <td>
  //                   <img src={ele.image} alt="img" width="50px" height="50px" />
  //                 </td>
  //                 <td className="title">{ele.title}</td>
  //                 <td>{ele.price}</td>
  //                 <td>{ele.category}</td>
  //                 <td>{ele.description}</td>
  //                 <td>
  //                   <EditData
  //                     type="edit"
  //                     viewData={viewData}
  //                     index={index}
  //                     handleViewData={handleViewData}
  //                     handlerChange={handlerViewDataChange}
  //                     handlerSubmit={handlerEditData}
  //                   />
  //                   <DeleteData
  //                     index={index}
  //                     handlerDeleteData={handlerDeleteData}
  //                   />
  //                 </td>
  //               </tr>
  //             ))
  //           )}
  //         </tbody>
  //       </table>
  //     </>
  //   );
}

export default ProductTable;
