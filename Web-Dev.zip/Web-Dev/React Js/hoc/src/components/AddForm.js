import React from "react";

function AddForm({ viewData, handlerChange }) {
  let { id, image, title, price, category, description } = {
    ...viewData,
  };
  return (
    <form>
      {/* <h3>Add Data</h3> */}
      <p>
        <img
          src={
            image
              ? image
              : "https://thecartridgeshoponline.co.uk/wp-content/uploads/2021/03/default-product-image.png"
          }
          alt="img"
          width="150px"
          height="150px"
        />
      </p>
      <div className="mb-3">
        <label htmlFor="exampleInputEmail1" className="form-label">
          id
        </label>
        <input
          type="number"
          className="form-control"
          id="exampleInputEmail1"
          aria-describedby="emailHelp"
          value={id}
          name="id"
          onChange={handlerChange}
        />
      </div>

      <div className="mb-3">
        <label htmlFor="exampleInputPassword1" className="form-label">
          image
        </label>
        <input
          type="text"
          className="form-control"
          id="exampleInputPassword1"
          value={image}
          name="image"
          onChange={handlerChange}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="exampleInputPassword1" className="form-label">
          Title
        </label>
        <input
          type="text"
          className="form-control"
          id="exampleInputPassword1"
          value={title}
          name="title"
          onChange={handlerChange}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="exampleInputPassword1" className="form-label">
          price
        </label>
        <input
          type="text"
          className="form-control"
          id="exampleInputPassword1"
          value={price}
          name="price"
          onChange={handlerChange}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="exampleInputPassword1" className="form-label">
          category
        </label>
        <input
          type="text"
          className="form-control"
          id="exampleInputPassword1"
          value={category}
          name="category"
          onChange={handlerChange}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="exampleInputPassword1" className="form-label">
          description
        </label>
        <input
          type="text"
          className="form-control"
          id="exampleInputPassword1"
          value={description}
          name="description"
          onChange={handlerChange}
        />
      </div>
    </form>
  );
}

export default AddForm;
