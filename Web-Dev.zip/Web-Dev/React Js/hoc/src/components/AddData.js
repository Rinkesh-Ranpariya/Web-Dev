import React, { useState } from "react";
import { Button } from "react-bootstrap";
import CommonModal from "./CommonModal";
import EditForm from "./EditForm";

const AddData = ({ viewData, handlerChange, handlerSubmit }) => {
  const [isModalOpen, setIsOpenModal] = useState(false);

  const toggle = () => {
    setIsOpenModal(!isModalOpen);
  };

  return (
    <>
      <Button variant="dark" onClick={() => toggle()}>
        Add
      </Button>
      {isModalOpen && (
        <CommonModal
          header={"Add Data"}
          toggle={toggle}
          body={<EditForm viewData={viewData} handlerChange={handlerChange} />}
          submitHandler={handlerSubmit}
          data={viewData}
        />
      )}
    </>
  );
};

export default AddData;
