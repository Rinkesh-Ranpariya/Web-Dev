import React from "react";
import { Table } from "react-bootstrap";

function CommonTable({ head, body }) {
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          {head.map((ele) => (
            <>
              <th>{ele}</th>
            </>
          ))}
        </tr>
      </thead>
      <tbody>{body}</tbody>
    </Table>
  );
}

export default CommonTable;
