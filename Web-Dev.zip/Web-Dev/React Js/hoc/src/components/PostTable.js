import axios from "axios";
import React, { useEffect, useState } from "react";
import CommonTable from "./CommonTable";

function PostTable() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        setData(res.data);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  return (
    <>
      {loading ? (
        "Loading..."
      ) : error ? (
        <h5>{error}</h5>
      ) : (
        <CommonTable
          head={["userId", "id", "title", "body"]}
          body={data.map((ele) => (
            <tr>
              <td>{ele.userId}</td>
              <td>{ele.id}</td>
              <td>{ele.title}</td>
              <td>{ele.body}</td>
            </tr>
          ))}
        />
      )}
    </>
  );
}

export default PostTable;
