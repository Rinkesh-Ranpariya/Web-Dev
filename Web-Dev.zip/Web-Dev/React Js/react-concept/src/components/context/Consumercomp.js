import React, { Component } from 'react'
import { bookContext } from './Provider'

export class Consumercomp extends Component {

  
  render() {
    // const contextType=bookContext
    // val=this.context
    return (
      <div>
        <bookContext.Consumer>
            {
                ele=> 
                <>
                <h1 className='mb-5'>Context</h1>
                <h2>📚 Book : {ele.name}</h2>
                <h2>💰 Price : {ele.price}</h2> 
                </>
            }
        </bookContext.Consumer>
      </div>
    )
  }
}

// Consumercomp.contextType=bookContext
// val=this.context
export default Consumercomp