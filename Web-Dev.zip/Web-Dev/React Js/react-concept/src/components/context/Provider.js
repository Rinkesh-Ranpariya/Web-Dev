import React, { Component } from 'react'
import Middle from './Middle'

export const bookContext=React.createContext({name:"India 2020",price:"50$"});
bookContext.displayName="Book"

class Provider extends Component {
  render() {
    return (
      <div>
          <bookContext.Provider value={{name:"Wings of Fire",price:"100$"}}>
            <Middle/>
          </bookContext.Provider>
      </div>
    )
  }
}

export default Provider 