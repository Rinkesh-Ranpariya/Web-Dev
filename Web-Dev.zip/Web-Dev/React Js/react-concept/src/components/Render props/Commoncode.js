import { Component } from "react";

export class Commoncode extends Component {
  constructor(props) {
    super(props);

    this.state = {
      count: 0,
    };
  }

  handler = () => {
    this.setState((pre) => ({ count: pre.count + 1 }));
  };

  render() {
    return this.props.render(this.state.count, this.handler);
    // return this.props.children(this.state.count, this.handler);
  }
}

export default Commoncode;
