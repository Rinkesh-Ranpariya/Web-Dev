import React, { Component } from "react";

export class Mouseover extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       count: 0,
//     };
//   }

//   handler = () => {
//     this.setState((pre) => ({ count: pre.count + 1 }));
//   };

  render() {
    const {count,handler}=this.props;
    return <h4 onMouseOver={handler}>Mouseover {count}</h4>;
  }
}

export default Mouseover;
