import React, { Component } from "react";

export class Click extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       count: 0,
//     };
//   }

//   handler = () => {
//     this.setState((pre) => ({ count: pre.count + 1 }));
//   };

  render() {
      const {count,handler}=this.props;
    return <button onClick={handler} className="btn btn-success mb-5">Click {count}</button>
  }
}

export default Click;
