import React, { Component } from 'react'

export class Child extends Component {
  render() {
    if(this.props.name==="bike"){
      throw new Error("Somthing went wrong !!!")
    }
    return <h3>Name : {this.props.name}</h3>
  }
}

export default Child