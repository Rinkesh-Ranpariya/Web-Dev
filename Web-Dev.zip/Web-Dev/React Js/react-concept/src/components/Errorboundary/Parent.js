import React, { Component } from "react";
import Child from "./Child";
import Errorboundary from "./Errorboundary";

export class Parent extends Component {
  render() {
    return (
      <div>
        <h1 className="mb-5">Error-Boundary ⁉️</h1>
        <Errorboundary>
          <Child name="truck" />
          <Child name="car" />
          <Child name="bike" />
        </Errorboundary>
      </div>
    );
  }
}

export default Parent;