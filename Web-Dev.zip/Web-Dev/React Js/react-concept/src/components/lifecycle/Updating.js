import React, { Component } from "react";
import Updatingc1 from "./Updatingc1";

export class Updating extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "Rinkesh" };
    console.log("parent constructor");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("parent getDerivedStateFromProps");
    return null;
  }

  componentDidMount() {
    console.log("parent componentDidMount");
  }

  shouldComponentUpdate(){
    console.log("parent shouldComponentUpdate");
    return true;
  }

  getSnapshotBeforeUpdate(prevProps,prevState){
    console.log("parent getSnapshotBeforeUpdate");
    return null;
  }

  componentDidUpdate(){
    console.log("parent componentDidUpdate");
  }

  handleClick=()=>{
    this.setState({name:"How are you ❓"})
  }

  render() {
    console.log("parent render");
    return (
      <>
        <h1>Updating</h1>
        <h3>{this.state.name} 👦</h3>
        <h5>Parent Updating</h5>
        <Updatingc1 />
        <input type="button" className='btn btn-primary' value="Greet him" onClick={this.handleClick}/>
      </>
    );
  }
}

export default Updating;
