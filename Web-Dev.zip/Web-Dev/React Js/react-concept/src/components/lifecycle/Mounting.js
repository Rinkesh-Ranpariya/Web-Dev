import React, { Component } from "react";
import Mountingc1 from "./Mountingc1";

export class Mounting extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "Rinkesh" };
    console.log("parent constructor");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("parent getDerivedStateFromProps");
    return null;
  }

  componentDidMount() {
    console.log("parent componentDidMount");
  }

  handleClick=()=>{
    this.setState({name:"How are you ❓"})
  }

  render() {
    console.log("parent render");
    return (
      <>
        <h1>Mounting</h1>
        <h3>{this.state.name} 👦</h3>
        <h5>Parent Mounting</h5>
        <Mountingc1 />
        <input type="button" className='btn btn-primary' value="Greet him" onClick={this.handleClick}/>
      </>
    );
  }
}

export default Mounting;
