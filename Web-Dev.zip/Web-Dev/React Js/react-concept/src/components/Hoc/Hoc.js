import React, { Component } from "react";

const Hoc = (Oldcomponent,value) => {
  
  class Hoc extends Component {
    constructor(props) {
      super(props);

      this.state = {
        count: 0,
      };
    }

    handler = () => {
      this.setState((pre) => ({ count: pre.count + value }));
    };

    render() {
      return <Oldcomponent h={this.handler} c={this.state.count} {...this.props} />;
    }
  }

  return Hoc;
};

export default Hoc;