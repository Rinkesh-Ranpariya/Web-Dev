import React, { Component } from "react";
import Hoc from "./Hoc";

export class Click extends Component {
  //   constructor(props) {
  //     super(props);

  //     this.state = {
  //       count: 0,
  //     };
  //   }

  //   handler = () => {
  //     this.setState((pre) => ({ count: pre.count + 1 }));
  //   };

  render() {
    const { h, c,name } = this.props;
    return <button onClick={h} className="btn btn-success">{name} {c}</button>;
  }
}

export default Hoc(Click,5);