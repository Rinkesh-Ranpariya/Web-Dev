import React, { Component } from "react";
import Hoc from "./Hoc";

export class Hover extends Component {
  //   constructor(props) {
  //     super(props);

  //     this.state = {
  //       count: 0,
  //     };
  //   }

  //   handler = () => {
  //     this.setState((pre) => ({ count: pre.count + 1 }));
  //   };

  render() {
    const { h, c, name } = this.props;
    return <h3 onMouseOver={h} className="mt-5">{name} {c}</h3>;
  }
}

export default Hoc(Hover,10);



