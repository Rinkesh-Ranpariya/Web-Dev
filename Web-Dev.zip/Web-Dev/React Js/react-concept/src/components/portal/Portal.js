import React from 'react'
import ReactDom from 'react-dom'

function Portal() {
  return ReactDom.createPortal(
    <h3>
        This is portal data... 
    </h3>,
    document.getElementById("portal")
  )
}

export default Portal 