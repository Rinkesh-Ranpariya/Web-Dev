import axios from "axios";
import { useEffect, useState } from "react";
import "./App.css";
import AddData from "./components/AddData";
import TableHead from "./components/TableHead";
import ViewData from "./components/ViewData";

function App() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  const [viewData, setViewData] = useState({
    index: "",
    id: "",
    image: "",
    title: "",
    price: "",
    category: "",
    description: "",
  });

  const [addNewData, setAddNewData] = useState({
    index: "",
    id: "",
    image: "",
    title: "",
    price: "",
    category: "",
    description: "",
  });

  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((res) => {
        setData(res.data);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  const handleDeleteData = (index) => {
    data.splice(index, 1);
    setData([...data]);
  };

  const handleViewData = (index) => {
    setViewData({
      index: index,
      id: data[index].id,
      image: data[index].image,
      title: data[index].title,
      price: data[index].price,
      category: data[index].category,
      description: data[index].description,
    });
  };

  const handlerViewDataChange = (e) => {
    setViewData({ ...viewData, [e.target.name]: e.target.value });
  };

  const handlerAddDataChange = (e) => {
    setAddNewData({ ...addNewData, [e.target.name]: e.target.value });
  };

  const handlerEditData = (index) => {
    data.splice(index, 1, viewData);
    setData([...data]);
  };

  const handlerAddNewData = () => {
    setData([addNewData, ...data]);
    setAddNewData({
      index: "",
      id: "",
      image: "",
      title: "",
      price: "",
      category: "",
      description: "",
    });
  };

  return (
    <div className="App">
      <div className="my-4">
        <AddData
          type="Add Data"
          index="jsn"
          handleViewData=""
          viewData={addNewData}
          handlerChange={handlerAddDataChange}
          handlerSubmit={handlerAddNewData}
        />
      </div>
      <table id="table" className="table">
        <TableHead />
        <tbody id="tableBody">
          {loading ? (
            "Loading..."
          ) : error ? (
            <h5>{error}</h5>
          ) : (
            data.map((ele, index) => (
              <tr className="trData" key={ele.id}>
                <td>{ele.id}</td>
                <td>
                  <img src={ele.image} alt="img" width="50px" height="50px" />
                </td>
                <td className="title">{ele.title}</td>
                <td>{ele.price}</td>
                <td>{ele.category}</td>
                <td>{ele.description}</td>
                <td>
                  <button
                    className="btn btn-danger"
                    onClick={() => handleDeleteData(index)}
                  >
                    Delete
                  </button>
                  <ViewData
                    type="View"
                    index={index}
                    handleViewData={handleViewData}
                    viewData={viewData}
                    handlerChange={handlerViewDataChange}
                    handlerSubmit={handlerEditData}
                  />
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default App;
