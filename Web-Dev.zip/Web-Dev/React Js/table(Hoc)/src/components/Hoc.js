import React from "react";
import Modal from "./Modal";

const Hoc = (Component) => {
  function Hoc(props) {
    return (
      <Component
        modal={
          <Modal
            type={props.type}
            index={props.index}
            handleViewData={props.handleViewData}
            viewData={props.viewData}
            handlerChange={props.handlerChange}
            handlerSubmit={props.handlerSubmit}
          />
        }
      />
    );
  }
  return Hoc;
};

export default Hoc;
