import React from "react";
import Hoc from "./Hoc";

function AddData({ modal }) {
  return <div>{modal}</div>;
}

export default Hoc(AddData);
