import React from "react";
import AddForm from "./AddForm";
import ViewForm from "./ViewForm";

function Modal({
  type,
  index,
  handleViewData,
  viewData,
  handlerChange,
  handlerSubmit,
}) {
  let { id, image, title, price, category, description } = {
    ...viewData,
  };
  return (
    <div>
      <div>
        <button
          type="button"
          className="btn btn-primary"
          data-bs-toggle="modal"
          data-bs-target={`#exampleModal${index}`}
          onClick={() => handleViewData(index)}
        >
          {type}
        </button>

        <div
          className="modal fade"
          id={`exampleModal${index}`}
          tabIndex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                  {type === "Add Data" ? "Add Data" : "Edit Data"}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                {type === "Add Data" ? (
                  <AddForm viewData={viewData} handlerChange={handlerChange} />
                ) : (
                  <ViewForm viewData={viewData} handlerChange={handlerChange} />
                )}
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  data-bs-dismiss="modal"
                  disabled={
                    !title ||
                    !image ||
                    !id ||
                    !price ||
                    !category ||
                    !description
                  }
                  onClick={
                    type === "View"
                      ? () => handlerSubmit(index)
                      : () => handlerSubmit()
                  }
                >
                  {type === "View" ? "Save Changes" : "Add Data"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Modal;
