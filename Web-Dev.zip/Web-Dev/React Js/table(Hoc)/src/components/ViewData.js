import React from "react";
import Hoc from "./Hoc";

function ViewData({ modal }) {
  return <div>{modal}</div>;
}

export default Hoc(ViewData);
