import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Table, Button } from "reactstrap";
import { useNavigate } from "react-router-dom";

function TableData({ data, loading, error }) {
  const [toggleSwitch, setToggleSwitch] = useState(false);
  const navigate = useNavigate();

  const handleClickTopToggleButton = () => {
    setToggleSwitch(!toggleSwitch);
  };

  const handleClickReadMore = (url) => {
    const data = { url, toggleSwitch };
    navigate("/readmore", { state: data });
  };

  return (
    <div>
      <Button color="primary" onClick={handleClickTopToggleButton}>
        {toggleSwitch ? "true" : "false"}
      </Button>
      <Table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Explore</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            "loading"
          ) : error ? (
            <h3>{error}</h3>
          ) : (
            data.map((ele) => (
              <tr key={ele.name}>
                <td>{ele.name}</td>
                <td>
                  <Button
                    color="primary"
                    onClick={() => handleClickReadMore(ele.url)}
                  >
                    Read More
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </Table>
    </div>
  );
}

export default TableData;
