import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Table, Button } from "reactstrap";

function ReadMore() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get(location.state.url)
      .then((res) => {
        setData(res.data.abilities);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  const handleClickBack = () => {
    navigate("/");
  };

  return (
    <>
      <Button color="primary" onClick={() => handleClickBack()}>
        Go Back
      </Button>
      <Table>
        <thead>
          <tr>
            <th>Name</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            "loading..."
          ) : error ? (
            <h3>{error}</h3>
          ) : (
            data.map((ele) => {
              if (location.state.toggleSwitch === ele.is_hidden) {
                return (
                  <tr key={ele.ability.name}>
                    <td>{ele.ability.name}</td>
                  </tr>
                );
              }
            })
          )}
        </tbody>
      </Table>
    </>
  );
}

export default ReadMore;
