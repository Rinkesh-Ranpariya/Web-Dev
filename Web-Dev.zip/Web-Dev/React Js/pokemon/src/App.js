import axios from "axios";
import { useEffect, useState } from "react";
import "./App.css";
import TableData from "./components/TableData";
import { Routes, Route } from "react-router-dom";
import ReadMore from "./components/ReadMore";

function App() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    axios
      .get("https://pokeapi.co/api/v2/pokemon")
      .then((res) => {
        setData(res.data.results);
        setError("");
      })
      .catch((err) => {
        setData([]);
        setError(err.message);
      });
    setLoading(false);
  }, []);

  return (
    <div className="App">
      <Routes>
        <Route
          path="/"
          element={
            <TableData
              data={data.slice(0, 10)}
              loading={loading}
              error={error}
            />
          }
        />
        <Route path="/readmore" element={<ReadMore />} />
      </Routes>
    </div>
  );
}

export default App;
