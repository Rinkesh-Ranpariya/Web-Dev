// c71ddba4cf74cef0bc564e24da952427

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//     apiKey: "AIzaSyC6cJygkXhx-74pyMJgg1PVFCWTY7B4pcQ",
//     authDomain: "netflix-30026.firebaseapp.com",
//     projectId: "netflix-30026",
//     storageBucket: "netflix-30026.appspot.com",
//     messagingSenderId: "933381128",
//     appId: "1:933381128:web:0e1e84f4c54a079d81bdbd",
//     measurementId: "G-KQMD897SR6"
//   };