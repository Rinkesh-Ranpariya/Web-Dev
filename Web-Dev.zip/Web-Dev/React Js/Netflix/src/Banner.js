import "./Banner.css"
import React,{useState,useEffect} from 'react'
import axios from "./axios.js";
import requests from "./requests.js"

const base_URL = "https://image.tmdb.org/t/p/original/";

function Banner() {

    const [movie, setMovie] = useState([])

    useEffect(() => {
        
        async function aaa() {
            const request = await axios.get(requests.fetchNetflixOriginals);
            setMovie(request.data.results[Math.floor(Math.random()*(request.data.results.length-1))]);
            return request;
          }
      
          aaa();

    }, [])

    // console.log(movie);

    return (
        <header className="banner"
            style={{
                backgroundSize:"cover",
                backgroundImage:`url(${base_URL}${movie?.backdrop_path})`,
                backgroundPosition:"center center"
            }}
        >
            <div className="banner_content">
                <h1 className="banner_title">
                    {movie?.title || movie?.name || movie?.original_name }
                </h1>
                <div className="banner_buttons">
                    <button className="banner_button">Play</button>
                    <button className="banner_button">My List</button>
                </div>
                <h1 className="banner_desc">
                    {movie?.overview}
                    {/* {(movie.overview.length > 150) ? movie.overview.substr(0, 150-1) + '...' : movie.overview} */}
                    
                </h1>
            </div>
            
            <div className="banner_fadebottom"/>

        </header>
    )
}

export default Banner
