import React, { useState, useEffect } from "react";
import instance from "./axios.js";
// import axios from "./axios.js";
import "./Row.css";
import YouTube from "react-youtube";
import movieTrailer from "movie-trailer";


const base_URL = "https://image.tmdb.org/t/p/original/";

function Row({ title, fetchUrl, isLarge }) {
  const [movies, setMovies] = useState([]);

  const [trailerurl, setTrailerurl] = useState("");

  useEffect(() => {
    async function aaa() {
      const request = await instance.get(fetchUrl);
      setMovies(request.data.results);
      // console.log(request);
      return request;
    }

    aaa();
  }, [fetchUrl]);


  const handlecli = (movie)=>{
    if(trailerurl){
      setTrailerurl("");
    }
    else{
      movieTrailer(movie?.name || "")
      .then(url =>{
        const param=new URLSearchParams(new URL(url).search);
        setTrailerurl(param.get('v'))
      })
      .catch(error=> console.log(error.message))
    }
  }

  const opts={
    height:"390",
    width:"100%",
    playerVars:{
      autoplay:1
    }
  }

  return (
    <div className="row">
      <h2>{title}</h2>
      <div className="row_posters">
        {movies.map((movie) => (
          <img
            key={movie.id}
            className={`row_poster ${isLarge && "row_posterLarge"}`}
            src={`${base_URL}${isLarge? movie.poster_path : movie.backdrop_path}`}
            alt={movie.name}
            onClick={()=> handlecli(movie)}
          />
        ))}
      </div>
      {trailerurl && <YouTube videoId={trailerurl} opts={opts} /> }
    </div>
  );
}

export default Row;
