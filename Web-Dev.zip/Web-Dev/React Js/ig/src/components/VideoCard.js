import "../css/VideoCard.css";
import VideoHeader from "./VideoHeader";
import VideoFooter from "./VideoFooter";

function VideoCard({ channel, avatarSrc, song, url, likes, shares }) {
  return (
    <div className="videoCard">
      <VideoHeader />
      <img className="videoCard_player" src={url} alt="img" loop />
      <VideoFooter
        channel={channel}
        avatarSrc={avatarSrc}
        song={song}
        likes={likes}
        shares={shares}
      />
    </div>
  );
}

export default VideoCard;
