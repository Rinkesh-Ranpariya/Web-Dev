let submit = document.getElementById("submit");

submit.addEventListener("click", (e) => {
  e.preventDefault();
  let numberValue = document.getElementById("number").value;

  let selectInput = document.getElementById("selectInput");
  let indexInput = selectInput.options[selectInput.selectedIndex].value;
  let selectOutput = document.getElementById("selectOutput");
  let indexOutput = selectOutput.options[selectOutput.selectedIndex].value;

  let answer = document.getElementById("answer");

  const cel = (fah) => (5 / 9) * (fah - 32);
  const fah = (cel) => (9 / 5) * cel + 32;

  if (indexInput === "cel" && indexOutput === "fah") {
    let ans = fah(numberValue);
    answer.innerHTML = `Ans : ${numberValue}cel = ${ans}fah`;
  } else if (indexInput === "fah" && indexOutput === "cel") {
    let ans = cel(numberValue);
    answer.innerHTML = `Ans : ${numberValue}fah = ${ans}cel`;
} else {
    answer.innerHTML = `Ans : ${numberValue}${indexInput} = ${numberValue}${indexOutput}`;
}
});


let reset = document.getElementById("reset");

reset.addEventListener('click',()=>{
    answer.innerHTML = `Ans : `;
})