let dark = document.getElementById("dark");
let op=document.getElementsByClassName('op');

let darkmode = () => {

  if (dark.classList.contains("dark")) {
    document.documentElement.style.backgroundColor = "white";
    document.documentElement.style.borderColor = "#FF5733";
    document.body.style.color = "black";

    dark.classList.remove("dark");
    dark.classList.add("light");
  } else if (dark.classList.contains("light")) {
    document.documentElement.style.backgroundColor = "black";
    document.documentElement.style.borderColor = "pink";
    document.body.style.color = "white";

    dark.classList.remove("light");
    dark.classList.add("dark");
  }


  // op.map((ele)=>{
  //   if(ele.classList.contains("social")){
  //     ele.classList.remove("social");
  //     ele.classList.add("media");
  //   }
  //   else if(ele.classList.contains("media")){
  //     ele.classList.remove("media");
  //     ele.classList.add("social");
  //   }
  // })

  // if(op.classList.contains("social")){
  //   op.classList.remove("social");
  //   op.classList.add("media");
  // }
  // else if(op.classList.contains("media")){
  //   op.classList.remove("media");
  //   op.classList.add("social");
  // }
};
