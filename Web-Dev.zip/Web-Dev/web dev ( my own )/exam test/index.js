//TODO:
//SET 1

// 1.
// person = {name, job, bdate, age, city}
// search and display persons array by age.
// display only those persons whose birthday is today.
// remove all the persons whose are under 18.

// 2.
// Show if square of number is exists in same array
// Input: [1,2,625,4,99,5,16,25,17,789,20,6,36,100]

// Output:
// number 1 => squared number 1
// number 2 => squared number 2

// 3. select day from drop down, it'll store days(sunday to saturday), select 2 dates as start date and end date.
// Find selcted day's date between start date to end date.

// ex: selected day from drop down : wednesday.
// start date = 01-02-2022 , end date = 10-02-2022

// output should be:
// 2 wednesday between 01-02-2022 to 10-02-2022 on  following days:
// 02-02-2022
// 09-02-2020

// 4.
// filter palindrom strings from array of strings.

//3.
// let submit = document.getElementById("submit");
// submit.addEventListener("click", () => {
//   let select = document.getElementById("select").value;

//   let startD = document.getElementById("start").value;
//   let endD = document.getElementById("end").value;

//   let start = new Date(startD);
//   let end = new Date(endD);

//   console.log(start);
//   console.log(end);

//   while (start <= end) {
//     if (start.getDay() == day)
//       if (start.getDate() <= end.getDate()) {
//       }
//   }
// });

//4.
// let a = ["abc", "aba", "dfdfdf", "sss"];

// let ans = a.filter((ele, index) => {
//   let pal = 1;
//   for (let index = 0; index <= ele.length / 2; index++) {
//     if (ele[index] !== ele[ele.length - index - 1]) {
//       pal = 0;
//       break;
//     }
//   }
//   if(pal==1){
//       return ele;
//   }
// });

// console.log(ans);

// --------------------------------------------------------------------------------------------------------------------------------------------------------

//TODO:
// Set 2

// 1.
// heros array to return a new array.

// The new array should rename the 'name' key to 'hero'.
// The 'name' key should not appear in the new array.
// The new array should have a new key added called (id).
// The key 'id' should be based on the index.

// const heros = [
//   { name: 'Spider-Man' },
//   { name: 'Thor' },
//   { name: 'Black Panther' },
//   { name: 'Captain Marvel' },
//   { name: 'Silver Surfer' }
// ];
// EXPECTED OUTPUT (array of objects):
// [
//   { id: 0, hero: 'Spider-Man' },
//   { id: 1, hero: 'Thor' },
//   { id: 2, hero: 'Black Panther' },
//   { id: 3, hero: 'Captain Marvel' },
//   { id: 4, hero: 'Silver Surfer' }
// ]

// 2.
// Write a function that, when passed an array and a target sum, returns, efficiently with
// respect to time used, two distinct zero-based indices of any two of the numbers, whose
// sum is equal to the target sum. If there are no two numbers, the function should return
// null. For example, findTwoSum([ 3, 1, 5, 7, 5, 9 ], 10) should return an array containing
// any of the following pairs of indices:
// 0 and 3 (or 3 and 0) as 3 + 7 = 10
// 1 and 5 (or 5 and 1) as 1 + 9 = 10
// 2 and 4 (or 4 and 2) as 5 + 5 = 10

// 3.
// Write a function that converts user entered date formatted as M/D/YYYY to a format
// required by an API (YYYYMMDD). The parameter "userDate" and the return value are
// strings. For example, it should convert user entered date "12/31/2014" to "20141231"
// suitable for the API.

// 4.
// Define a function called cleanNames that accepts an array of strings containing additional space characters at the beginning and end. The cleanNames() function should use the array map method to return a new array full of trimmed names. For example:

// cleanNames([" avengers", "   captain_america", "ironman   ", " black panther   "])
// should give
// ["avengers", "captain_america", "ironman", "black panther"]

//2.
// let ans = [];
// function findTwoSum(array, sum) {
//   let present = 0;
//   for (let i = 0; i < array.length - 1; i++) {
//     for (let j = i+1; j < array.length; j++) {
//       if (array[i] + array[j] == sum) {
//         present = 1;
//         ans.push([i, j]);
//       }
//     }
//   }

//   if (present == 0) {
//     ans.push(null);
//   }
// }

// let arr = [3, 1, 5];
// findTwoSum(arr, 8);
// console.log(ans);

//3.
// function changeDate(dat){
//     let [d,m,y]=dat.split("/");
//     return requiredFormate=y+m+d;
// }
// console.log( changeDate(new Date('12/25/2001').toLocaleDateString()));

//4.
// function cleanNames(arr){
//     let trim=arr.map((ele)=>{
//         return ele.trim();
//     });
//     return trim;
// }

// let arr=[" avengers", "   captain_america", "ironman   ", " black panther   "];
// let ans =cleanNames(arr);

// console.log(ans);

// --------------------------------------------------------------------------------------------------------------------------------------------------------

//TODO:
// Set 3
// ----------------------
// 1.
// Create a method in the Person class which returns how another person's age compares.
// Given the instances p1, p2 and p3, which will be initialised with the attributes name and age,
// return a sentence in the following format:

// {older than / younger than / same age as} me.

// Examples
// p1 = Person("Samuel", 24)
// p2 = Person("Joel", 36)
// p3 = Person("Lily", 24)
// p1.compareAge(p2) ➞ "elder than me."

// p2.compareAge(p1) ➞ "younger than me"

// p1.compareAge(p3) ➞ "same age as me."

// 2.
// Consider the following array:
// let nums = [11, 22, 33, 46, 75, 86, 97, 98];

// filter even numbers then square them. Assign the result to a variable named squaredEvenNums and display it.
// The output should be:
// squaredEvenNums: [484, 2116, 7396, 9604]

// calculate the sum of nums array. The output should be:
// Sum of array elements: 468

// 3.
// Christmas Eve is almost upon us, so naturally we need to prepare some milk and cookies for Santa!
// Create a function that accepts a Date object and returns true if it's Christmas Eve (December 24th) and false otherwise.
// Keep in mind JavaScript's Date month is 0 based, meaning December is the 11th month while January is 0.

// Examples
// timeForMilkAndCookies(new Date(2013, 11, 24)) ➞ true

// timeForMilkAndCookies(new Date(2013, 0, 23)) ➞ false

// timeForMilkAndCookies(new Date(3000, 11, 24)) ➞ true

// 4.
// count each words in given paragraph.

//2.
// let nums = [11, 22, 33, 46, 75, 86, 97, 98];
// let squaredEvenNums = nums.filter((ele) => {
//   if (ele % 2 == 0) {
//     return ele;
//   }
// }).map((ele)=>ele**2);
// let sum = nums.reduce((ac, ele) => (ac += ele));
// console.log(squaredEvenNums);
// console.log(sum);

//3.
// function timeForMilkAndCookies(date) {

//     let [d,m,y]=date.split("/");

//     if(+(d+m) == 2412){
//         return true;
//     }
//     else{
//         return false;
//     }
// }

// let ans =timeForMilkAndCookies(new Date(2013,11,22).toLocaleDateString())
// console.log(ans);

//4.
// let a = "harsh harsh harsh gfdasg fbdgdfgdg dgdag";
// let b = a.split(" ");
// let d = {};
// for (ele1 of b) {
//   let c = 0;
//   for (ele of b) {
//     if (ele1 === ele) {
//       c++;
//     }
//   }
//   d[ele1]=c;
// }
// console.log(d)

//TODO:
//--------------------------------------------------------------------------------------------------------------------------------------------------------

// Set 4

// const objectArr = [
//     {
//         id: 1,
//         value: "abc"
//     },
//     "bob",
//     "aris",
//     {
//         id: 2,
//         value: "xyz"
//     },
//     {
//         id: 3,
//         value: "nimo"
//     },
//     {
//         id: 4,
//         value: "keshav"
//     },
//     "Kelvin",
//     "Amy",
//     "sheldon"
// ]

// 1 > output should be:
// [{
//     id: 1,
//     value: "abc"
// },
// {
//     id: "bob",
//     value: "bob"
// },
// {
//     id: "aris",
//     value: "aris",
// },
// {
//     id: 2,
//     value: "xyz"
// },
// {
//     id: 3,
//     value: "nimo"
// },
// {
//     id: 4,
//     value: "keshav"
// },
// {
//     id: "kelvin",
//     value: "Kelvin"
// },
// {
//     id: "amy",
//     value: "Amy"
// },
// {
//     id: "sheldon",
//     value: "sheldon"
// }
// ]
// note: where we don't have an object and only string convert it to the object and id should stored in small letter but value should be same as string.

// 3.const arr = ["zyx", "nys", "as", "d", "e", "kkkk", "78"]
// delete strings with unique length

// 4.const arr4 = [
//     {
//         id: 1,
//         value: "abc",
//         child: [
//             {
//                 id: "abc"
//             },
//             {
//                 id: "dog"
//             },
//         ]
//     },
//     {
//         id: "bob",
//         value: "bob",
//         child: [
//             {
//                 id: "abc"
//             },
//             {
//                 id: "dog"
//             },
//             {
//                 id: "bob"
//             },
//             {
//                 id: "dog"
//             },
//         ]
//     },
//     {
//         id: "aris",
//         value: "aris",
//     },
//     {
//         id: 2,
//         value: "xyz"
//     },
//     {
//         id: 3,
//         value: "nimo",
//         child: [
//             {
//                 id: "bob"
//             },
//             {
//                 id: "dog"
//             },
//             {
//                 id: "nimo"
//             },
//             {
//                 id: "dog"
//             },
//         ]
//     },
//     {
//         id: 4,
//         value: "keshav"
//     },
//     {
//         id: "kelvin",
//         value: "kelvin"
//     },
//     {
//         id: "amy",
//         value: "amy"
//     },
//     {
//         id: "sheldon",
//         value: "sheldon"
//     }
// ]

// output:
// [
//     {
//         id: 1,
//         value: "abc",
//         child: [
//             {
//                 id: "abc",
//                 childvalue:"ABC"
//             },
//         ]

//     },
//     {
//         id: "bob",
//         value: "bob",
//         child: [
//             {
//                 id: "bob",
//                 childvalue:"BOB"
//             },
//         ]
//     },
//     {
//         id: "aris",
//         value: "aris",
//     },
//     {
//         id: 2,
//         value: "xyz"
//     },
//     {
//         id: 3,
//         value: "nimo",
//         child: [
//             {
//                 id: "nimo",
//                 childvalue:"NIMO"
//             },
//         ]
//     },
//     {
//         id: 4,
//         value: "keshav"
//     },
//     {
//         id: "kelvin",
//         value: "kelvin"
//     },
//     {
//         id: "amy",
//         value: "amy"
//     },
//     {
//         id: "sheldon",
//         value: "sheldon"
//     }
// ]

// 5.let arr1=[
//     {
//         id:1,
//         name:"bob"
//     },
//     {
//         id:2,
//         name:"sam"
//     },
//     {
//         id:3,
//         name:"jimmy"
//     },
//     {
//         id:4,
//         name:"nimol"
//     },
// ]

// let arr2=[
//     {
//         id:2,
//         name:"sam",
//         salary:47854
//     },
//     {
//         id:4,
//         name:"nimol",
//         salary:84944
//     },
//     {
//         id:3,
//         name:"jimmy",
//         salary:28444
//     },
//     {
//         id:1,
//         name:"bob",
//         salary:48494
//     },
// ]

// arr3=[
//     {
//         id:2,
//         isemployee:true
//     },
//     {
//         id:3,
//         isemployee:true
//     }
// ]

// merge those 3 arrays
// output:
// [
//     {
//         id:1,
//         name:"bob",
//         salary:48494
//     },
//     {
//         id:2,
//         name:"sam",
//         salary:47854,
//         isemployee:true
//     },
//     {
//         id:3,
//         name:"jimmy",
//         salary:28444,
//         isemployee:true
//     },
//     {
//         id:4,
//         name:"nimol",
//         salary:84944
//     },
// ]

//1.
// let objectArr = [
//   {
//     id: 1,
//     value: "abc",
//   },
//   "bob",
//   "aris",
//   {
//     id: 2,
//     value: "xyz",
//   },
//   {
//     id: 3,
//     value: "nimo",
//   },
//   {
//     id: 4,
//     value: "keshav",
//   },
//   "SMIT",
//   "Amy",
//   "sheldon",
// ];

// let ansArr=objectArr.map((ele)=>{
//     let ans=(typeof(ele)!= "object")? {id:ele.toLowerCase(),value:ele}:ele;
//     return ans;
// })
// console.log(ansArr);

//3.

// let array = ["zyx", "nysll","1234567","es", "as", "d", "e", "78"];

// let ans=[];

// for (let i = 0; i < array.length; i++) {
//     for (let j = 0; j < array.length; j++) {
//         if(i==j){
//             continue;
//         }
//         else if(array[i].length===array[j].length){
//             ans.push(array[i]);
//             break;
//         }
//     }
// }

// console.log(ans);

//4.
// arr = [
//   {
//     id: 1,
//     value: "abc",
//     child: [
//       {
//         id: "abc",
//       },
//       {
//         id: "dog",
//       },
//     ],
//   },
//   {
//     id: "bob",
//     value: "bob",
//     child: [
//       {
//         id: "abc",
//       },
//       {
//         id: "dog",
//       },
//       {
//         id: "bob",
//       },
//       {
//         id: "dog",
//       },
//     ],
//   },
//   {
//     id: "aris",
//     value: "aris",
//   },
//   {
//     id: 2,
//     value: "xyz",
//   },
//   {
//     id: 3,
//     value: "nimo",
//     child: [
//       {
//         id: "bob",
//       },
//       {
//         id: "dog",
//       },
//       {
//         id: "nimo",
//       },
//       {
//         id: "dog",
//       },
//     ],
//   },
//   {
//     id: 4,
//     value: "keshav",
//   },
//   {
//     id: "kelvin",
//     value: "kelvin",
//   },
//   {
//     id: "amy",
//     value: "amy",
//   },
//   {
//     id: "sheldon",
//     value: "sheldon",
//   },
// ];

// arr.forEach((ele) => {
//   if (ele.child) {
//     ele.child = [{ id: ele.value.toLowerCase(), childvalue: ele.value.toUpperCase() }];
//   }
// });

// console.log(arr);
