// $(document).ready(function(){

//     $("#div-4-bu").click(function() {

//         if($("#img2").html()===`<img src="./computer2.jpg"
//         class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid" width="500"
//         height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500"
//         preserveAspectRatio="xMidYMid slice" focusable="false">`){
//             $("#img2").html(`<img src="./computer2b.jpg"
//             class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid" width="500"
//             height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500"
//             preserveAspectRatio="xMidYMid slice" focusable="false">`);
//         }
//         else if($("#img2").html()===`<img src="./computer2b.jpg"
//         class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid" width="500"
//         height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500"
//         preserveAspectRatio="xMidYMid slice" focusable="false">`){
//             $("#img2").html(`<img src="./computer2.jpg"
//             class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid" width="500"
//             height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500"
//             preserveAspectRatio="xMidYMid slice" focusable="false">`);
//         }

//     })

//   });

// $(document).ready(function () {
//   $("#div-4-bu").click(function () {

//     if($("#img2").css("display")=="block")
//     {
//         $("#img2").css("display", "none")    
//     }
//     $("#img2").css("display", "block");
//   });
// });
